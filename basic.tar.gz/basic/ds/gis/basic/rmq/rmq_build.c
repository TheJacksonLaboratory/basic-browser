#include"rmq.h"

uint8_t compact_bucket(int16_t value[], unsigned int bucket_size, uint8_t index[])
{
	int16_t prev;
	unsigned int i, j;
	for (i = j = 1, prev = value[0], index[0] = 0; i < bucket_size; i++)
		if (value[i] != prev) {
			value[j] = value[i];
			index[j++] = i;
			prev = value[i];
		}
	return j;
}

void process_table (unsigned int tsize, int16_t **table)
{
	unsigned int i, j;
	for (j = 1; 1 << j <= tsize; j++)
		for (i = 0; i + (1 << j) - 1 < tsize; i++)
			if (table[i][j - 1] > table[i + (1 << (j - 1))][j - 1])
				table[i][j] = table[i][j - 1];
			else
				table[i][j] = table[i + (1 << (j - 1))][j - 1];
}

void rmq_build (char outfile[], char filename[], int numOfElements)
{
	bool stop = false;
	const unsigned int bucket_size = RMQ_BSIZE;
	const unsigned int block_size = RMQ_BSIZE * RMQ_BSIZE;
	unsigned int bucket_count, block_count;
	unsigned int buffer[bucket_size];
	
	int16_t **block_table;
	int16_t **bucket_table;
	uint8_t *compacted_bucket_size;
	uint8_t bucket_index[RMQ_BSIZE];
	int16_t bucket_value[RMQ_BSIZE];
	long *bucket_address;
	FILE *fp;

unsigned int i, j; // indexes
unsigned int L, logL; // number of buckets in a block
unsigned int M, logM; // number of blocks
unsigned int N, K; // total elements and buckets

long bucket_tables_start_addr;
long bucket_contents_start_addr;
	
	int16_t v;
	int16_t bucket_max, block_max;
	int16_t value[bucket_size];
	uint8_t index[bucket_size];
	
	FILE *fp_input;
	FILE *fp_output;
	
	unsigned int total_bucket_size = 0;
	long bucket_tables_address;
	long bucket_content_address;
	
	N = numOfElements;
	L = block_size / bucket_size; // number of buckets in a block
	M = N / block_size + 1; // number of blocks
	
	logL = log(L) / log(2.0) + 1;
	logM = log(M) / log(2.0) + 1;
	
	printf("Original number of elements: %u.\n", N);
	printf("The block table size is %u x %u.\n", M, logM);
	printf("The bucket table size is %u x %u.\n", L, logL);
		
	// initialize tables
	block_table = malloc(M * sizeof(int16_t *));
	for (i = 0; i < M; i++)
		block_table[i] = malloc(logM * sizeof(int16_t));
		
	bucket_table = malloc(L * sizeof(int16_t *));
	for (i = 0; i < L; i++)
		bucket_table[i] = malloc(logL * sizeof(int16_t));
	
	// bucket info
	compacted_bucket_size = malloc(M * L * sizeof(uint8_t));
	bucket_address = malloc(M * L * sizeof(long));
	
	fp_input = fopen(filename, "r");
	fp_output = fopen(outfile, "wb");
	buffer[0] = M;
	
	if (fwrite(buffer, sizeof(unsigned int), 1, fp_output) != 1) // write the total number of blocks
		perror("WRITE ERROR");
	if (fseek(fp_output, M * logM * sizeof(int16_t), SEEK_CUR)) // skip block_table at the moment
		perror("SEEK ERROR");
	
	bucket_tables_address = ftell(fp_output); // save the bucket tables starting point
	printf("%ld\n", bucket_tables_address); // print the first address of bucket tables
	
	if (fseek(fp_output, M * L * logL * sizeof(int16_t), SEEK_CUR)) // skip bucket tables at the moment
		perror("SEEK ERROR");
	if (fseek(fp_output, M * L * (sizeof(uint8_t) + sizeof(long)), SEEK_CUR)) // skip bucket info at the moment
		perror("SEEK ERROR");
	
	bucket_content_address = ftell(fp_output); // save the bucket contents starting point
	printf("%ld\n", bucket_content_address); // print the first address of bucket contents
	
	// main loop, get all the numbers
	// read one block at a time
	for (block_count = bucket_count = 0; block_count < M; block_count++) {
		block_max = 0;
		
		if (fseek(fp_output, bucket_content_address, SEEK_SET)) perror("SEEK ERROR");
		// scan for L buckets of a block
		for (i = 0; i < L; i++, bucket_count++) {
			bucket_max = 0;
			// scan a single bucket
			for (j = 0; j < bucket_size; j++) {
				if (fscanf(fp_input, "%hd", &v) != EOF) {
					value[j] = v;
					if (v > bucket_max) bucket_max = v;
					if (v > block_max) block_max = v;
				} else {
					value[j] = SHRT_MIN;
					stop = true;
				}
			}
			bucket_table[i][0] = bucket_max; // store initial value in bucket table
			
			// compact the current bucket and write its info to disk
			compacted_bucket_size[bucket_count] = compact_bucket(value, bucket_size, index);
			total_bucket_size += compacted_bucket_size[bucket_count];
			bucket_address[bucket_count] = ftell(fp_output);
			fwrite(index, sizeof(uint8_t), compacted_bucket_size[bucket_count], fp_output);
			fwrite(value, sizeof(int16_t), compacted_bucket_size[bucket_count], fp_output);
		}
		
		bucket_content_address = ftell(fp_output); // save the next bucket start position
		// store initial value in block table
		if (block_count < M) block_table[block_count][0] = block_max;
		
		// process the ith bucket table and write to disk
		process_table(L, bucket_table);
		if (fseek(fp_output, bucket_tables_address, SEEK_SET)) perror("ERROR");
		for (i = 0; i < L; i++)
			fwrite(bucket_table[i], sizeof(int16_t), logL, fp_output);
		bucket_tables_address = ftell(fp_output); // save the next table start position
	}	
	fclose(fp_input);
	printf("There are %u blocks and %u buckets in total.\n", block_count, bucket_count);
	
	// process the block table and write to disk
	fseek(fp_output, sizeof(unsigned int), SEEK_SET);
	process_table(block_count, block_table);
	for (i = 0; i < M; i++)
		fwrite(block_table[i], sizeof(int16_t), logM, fp_output);
		
	// write the actual bucket size and contents pointer
	if (fseek(fp_output, bucket_tables_address, SEEK_SET)) perror("ERROR");
	fwrite(compacted_bucket_size, sizeof(uint8_t), M * L, fp_output);
	fwrite(bucket_address, sizeof(long), M * L, fp_output);
	fclose(fp_output);
	
	printf("Total bukcet size: %u.\n", total_bucket_size);
	
	// initialize tables
	for (i = 0; i < M; i++)
		free(block_table[i]);
	free(block_table);
	
	for (i = 0; i < L; i++)
		free(bucket_table[i]);
	free(bucket_table);
	
	// bucket info
	free(compacted_bucket_size);
	free(bucket_address);
}

