
#include "seq_access.h"
#include "../_mmap/fosm.h"
#include <fstream>

using namespace std;


struct SeqAccDS {
	sptr<DataGroup> config;
	UI64ExtBArr arr;
	uint64_t dnalen;
};

unsigned char encode(char c) {
	unsigned char ec = 0;
	switch (c) {
	case 'A': ec = 0; break;
	case 'C': ec = 1; break;
	case 'G': ec = 2; break;
	case 'T': ec = 3; break;
	case 'a': ec = 4; break;
	case 'c': ec = 5; break;
	case 'g': ec = 6; break;
	case 't': ec = 7; break;
	case 'N': ec = 8; break;
	default:
		throw runtime_error((string("encounter unknown character: ") + c).c_str()); break;
	}
	return ec;
}

std::pair<std::string, unsigned int> extract_number(const std::string& line) {
	int i = 0;
	unsigned int slen = 0;
	if (line.length() == 0 || line[0] != '>')
		throw runtime_error("file format is incorrect");
	for (i = line.length() - 1; i > 0; i--)
		if (line[i] == ',') {
			string ns = line.substr(i + 1);
			if (sscanf(ns.c_str(), "%ul", &slen) == EOF) 
				throw runtime_error("cannot convert to unsigned integer");
			else
				return make_pair(line.substr(1, i), slen);
		}
	throw runtime_error("cannot find length");
}

void build(const char* input, const char* outputfile, const char* datadir) {
	ifstream fi(input);
	string line;
	sptr<DataGroup> opt = sptr<DataGroup>(new DataGroup());
	opt->set_datatype("seq_access");
	getline(fi, line);
	std::pair<std::string, unsigned int> rs = extract_number(line);
	if (rs.second == 0) throw runtime_error("unexpected 0 length");

	opt->add_str("version", "1.0");
	opt->add_str("description", "4-bit code");
	opt->add_str("sequence_name", rs.first);
	opt->add_uint64("dna_length", rs.second);
	opt->add_str("$FILE_PATH", datadir);
	
	UI64ExtBArr arr = opt->new_uint64arr("compact_dna", (rs.second - 1)*4/64 + 1);

	unsigned int i = 0;
	while (fi.good()) {
		char ch = fi.get();
		if (ch != '\n' && ch != '\r' && fi.good()) {
			arr.set_bits(i*4, encode(ch), 4);
			++i;
		}
	}
	if (i != rs.second)
		throw runtime_error("real sequence length does not equal the specified number");
	DataGroup::write_properties(outputfile, opt);
	//arr.close();
}

SAHandle load(const char* outputfile) {
	SAHandle a = new SeqAccDS();
	a->config = DataGroup::read_properties(outputfile);
	if (a->config->group_type() != "seq_access") throw runtime_error("wrong type");
	string version = a->config->get_str("version");
	if (version.length() < 2 || version.substr(0, 2) != "1.") throw runtime_error("cannot load this version");
	a->dnalen = a->config->get_uint64("dna_length");
	a->arr = a->config->open_uint64arr("compact_dna");
	if (!a->arr.compat_bitlen(a->dnalen * 4)) throw std::runtime_error("incompatible lengths");
	return a;
}

void unload(SAHandle h) {
	delete h;
}

char decode(unsigned char val) {
	switch (val) {
	case 0: return 'A';
	case 1: return 'C';
	case 2: return 'G';
	case 3: return 'T';
	case 4: return 'a';
	case 5: return 'c';
	case 6: return 'g';
	case 7: return 't';
	case 8: return 'N';
	}
	throw runtime_error("unknown code");
}

char* substring(SAHandle h, unsigned int start, unsigned int length) {
	if(length > 4096) throw std::runtime_error("requested string is too long");
	if (start > h->dnalen || start + length > h->dnalen + 1 || start == 0) throw runtime_error("index out of range");
	start -= 1;
	char* ret = new char[length + 1];
	for (unsigned int i = 0; i < length; ++i) {
		unsigned char val = (unsigned char) h->arr.get_bits(4*(i+start), 4);
		ret[i] = decode(val);
	}
	ret[length] = 0;
	return ret;
}
