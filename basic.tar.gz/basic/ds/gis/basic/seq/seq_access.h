#pragma once

#ifndef __SEQ_ACCESS_H_
#define __SEQ_ACCESS_H_

struct SeqAccDS;

typedef SeqAccDS * SAHandle;

void build(const char* input, const char* outputfile, const char* datadir);

SAHandle load(const char* outputfile);
void unload(SAHandle);

char* substring(SAHandle h, unsigned int start, unsigned int length);

#endif //__SEQ_ACCESS_H_
