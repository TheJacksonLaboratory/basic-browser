
#include <stdio.h>
#include <stdlib.h>
#include <stdexcept>
#include <string>

#ifdef WIN32
#define PAGE_READONLY          0x02     
#define SECTION_MAP_READ    0x0004
#define FILE_MAP_READ       SECTION_MAP_READ

#else
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#endif

#include "mmap.h"

#ifndef min
#define min(x,y) (((x)<(y))?(x):(y))
#endif

#ifndef MAP_ANONYMOUS
#define MAP_ANONYMOUS MAP_ANON
#endif

#ifdef WIN32
MMAP *mymmap(const char *fname) {
	void *base;
	HANDLE fd,h;
	size_t len;
	MMAP *m;
	m = (MMAP*) malloc(sizeof(*m));
	if (m==NULL) {perror("mymmap malloc");  exit(1);}
	fd = CreateFile(fname,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,NULL);
	if (fd==INVALID_HANDLE_VALUE) {
		throw std::runtime_error("createfile\n");
	}
	m->h1 = fd;
	len = GetFileSize(fd,0) - 1;
	len++;
	m->len = len;
	//h = CreateFileMapping (fd, NULL, PAGE_READONLY, 0, len, NULL);
	h = CreateFileMapping(fd, NULL, PAGE_READONLY, 0, 0, NULL);
	if (h==NULL) {
		throw std::runtime_error("createfilemapping\n");
	}
	m->h2 = h;
	//base = MapViewOfFile (h, FILE_MAP_READ, 0, 0, len);
	base = MapViewOfFile(h, FILE_MAP_READ, 0, 0, 0);
	if (base==NULL) {
		throw std::runtime_error("mapviewoffile\n");
	}
	m->addr = base;
	return m;
}

int mymunmap (MMAP *m)
{
	UnmapViewOfFile(m->addr);
	CloseHandle(m->h2);
	CloseHandle(m->h1);
	return 0;
}

MMAP *mymmap_w(const char *fname, uint64_t len) {
	void *base;
	HANDLE fd,h;
	//size_t len;
	MMAP *m;
	m = (MMAP*) malloc(sizeof(*m));
	if (m==NULL) {perror("mymmap malloc");  exit(1);}
	fd = CreateFile(fname,(GENERIC_READ|GENERIC_WRITE),FILE_SHARE_READ,NULL,CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,NULL);
	if (fd==INVALID_HANDLE_VALUE) {
		throw std::runtime_error("createfile\n");
	}
	m->h1 = fd;
	LARGE_INTEGER li;
	li.QuadPart = len;
	if (!SetFilePointerEx(fd, li, NULL, FILE_BEGIN)) {
		throw std::runtime_error("cannot set pointer ");
	}
	if (!SetEndOfFile(fd)) {
		throw std::runtime_error("cannot set end of file");
	}
	h = CreateFileMapping(fd, NULL, PAGE_READWRITE, 0, 0, NULL);
	if (h==NULL) {
		throw std::runtime_error("createfilemapping\n");
	}	
	m->h2 = h;
	base = MapViewOfFile(h, FILE_MAP_ALL_ACCESS, 0, 0, 0);
	if (base==NULL) {
		throw std::runtime_error("mapviewoffile\n");
	}	
	m->addr = base;
	return m;
}


#else

MMAP *mymmap(const char *fname)
{
	int fd;
	size_t len;
	MMAP *m;
	struct stat statbuf;
	caddr_t base;
	m =(MMAP*) malloc(sizeof(*m));
	if (m==NULL) { throw std::runtime_error("mymmap malloc");}

	stat(fname,&statbuf);
	len = statbuf.st_size;
	fd = open(fname,O_RDONLY);
	//  fd = open(fname,O_RDWR);
	if (fd == -1) {
		throw std::runtime_error((std::string("open file: \'") + fname + "\'").c_str());
	}
	base = (caddr_t)mmap(0,len,PROT_READ,MAP_SHARED,fd,0);
	//  base = (void *)mmap(0,len,PROT_READ | PROT_WRITE,MAP_SHARED,fd,0);
	if (base==(caddr_t)-1) {
		throw std::runtime_error("mmap1\n");
	}
	m->addr = (void *)base;
	m->fd = fd;
	m->len = len;
	return m;
}

MMAP *mymmap_w (const char *fname, uint64_t len)
{
	int fd;
	MMAP *m;
	caddr_t base;
	char c;

	m = (MMAP*) malloc(sizeof(*m));
	if (m==NULL) {throw std::runtime_error("mymmap_w malloc");  }

	/*
	struct stat statbuf;
	size_t old_len;
	if (stat(fname,&statbuf) == 0) {
		old_len = statbuf.st_size;
	} else { // does not exist?
		old_len = 0;
	}*/

	//fd = open(fname,O_RDWR | O_CREAT);
	//fd = open(FILEPATH, O_RDWR | O_CREAT | O_TRUNC, (mode_t)0600);
	fd = open(fname,O_RDWR | O_CREAT | O_TRUNC,  S_IRUSR | S_IWUSR );
	if (fd == -1) {free(m); throw std::runtime_error("mymmap_w: open1\n");}
	fchmod(fd, 0644);
	int result = lseek(fd, len-1, SEEK_SET);
	if (result == -1) {
		close(fd);free(m); 
		throw std::runtime_error("Error calling lseek() to 'stretch' the file");
    }
	result = write(fd, "", 1);
	if (result != 1) {
		close(fd);free(m); 
		throw std::runtime_error("Error writing last byte of the file");
	}

	lseek(fd, 0, SEEK_SET);

	base = (caddr_t)mmap(0,len,PROT_READ | PROT_WRITE,MAP_SHARED,fd,0);
	if (base==MAP_FAILED) {close(fd); free(m); throw std::runtime_error("mymmap_w\n");}
	m->addr = (void *)base;
	m->fd = fd;
	m->len = len;
	return m;
}

void *mymremap(MMAP *m, size_t new_len)
{
	unsigned char *buf;
	long l,bs;
	caddr_t base;
	struct stat statbuf;

	if (msync(m->addr, m->len, MS_ASYNC)) {
		throw std::runtime_error("msync\n");
		
	}
	if (munmap(m->addr,m->len)==-1) {
		throw std::runtime_error("mymremap 1:");
	}

	if (m->fd != -1) {
		if (new_len > m->len) {
			bs = 1<<16;
			buf = (unsigned char*) malloc(bs);
			if (buf==NULL) {throw std::runtime_error("mymremap: malloc buf");  }
			for (l=0; l<bs; l++) buf[l] = 0;

			if (lseek(m->fd, m->len, SEEK_SET) == -1) {
				throw std::runtime_error("mymremap: lseek"); 
			}
			l = new_len - m->len;
			while (l > 0) {
				long s;
				//      printf("write %ld \r",l);  fflush(stdout);
				s = min(l, bs);
				if (write(m->fd, buf, s) != s) {
					throw std::runtime_error("mymremap: write"); 
				}
				l -= s;
			}
			free(buf);

		} else {
#if 0
			if (lseek(m->fd, new_len, SEEK_SET) == -1) {
				throw std::runtime_error("mymremap: lseek2"); 
			}
			if (write(m->fd, &l, 0) != 0) {
				throw std::runtime_error("mymremap: write2"); 
			}
#else
			if (ftruncate(m->fd, new_len)) {
				throw std::runtime_error("mymremap: ftruncate"); 
			}
#endif
		}
	}
	if (m->fd == -1) {
		base = (caddr_t)mmap(0,new_len,PROT_READ | PROT_WRITE,MAP_PRIVATE | MAP_ANONYMOUS,m->fd,0);
	} else {
		base = (caddr_t)mmap(0,new_len,PROT_READ | PROT_WRITE,MAP_SHARED,m->fd,0);
	}
	if (base==MAP_FAILED) {
		throw std::runtime_error("mymremap: mmap\n");
	}
	m->addr = (void *)base;
	m->len = new_len;

	return m->addr;
}

MMAP *mymmap_anom(size_t len)
{
	int fd;
	MMAP *m;
	caddr_t base;
	m = (MMAP*) malloc(sizeof(*m));
	if (m==NULL) {throw std::runtime_error("mymmap malloc");  }

	fd = -1;
	base = (caddr_t)mmap(0,len,PROT_READ | PROT_WRITE,MAP_PRIVATE | MAP_ANONYMOUS,fd,0);
	if (base==MAP_FAILED) {
		throw std::runtime_error("mymmap_anom\n");
	}
	m->addr = (void *)base;
	m->fd = fd;
	m->len = len;
	return m;
}

int mymunmap(MMAP *m)
{
	if (munmap(m->addr,m->len)==-1) {
		throw std::runtime_error("munmap 1:");
	}
	close(m->fd);
	return 0;
}                
#endif
