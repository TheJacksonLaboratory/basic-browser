#ifndef AVG_H
#define AVG_H

#include<assert.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<string.h>

#define MAX_GROUPS 10000000
#define MAX_SEGMENTS_PER_GROUP 4
#define MAX_BITS_PER_SEGMENT 64
typedef struct node *AVG_Struct;

AVG_Struct init(char *input, unsigned int mode);
void unload(AVG_Struct s);
unsigned int average(AVG_Struct s, unsigned int chrom, unsigned int i, unsigned int j);
unsigned int sum(AVG_Struct a, unsigned int chrom, unsigned int i, unsigned int j);
void build(char *infofile, char *infile, char *tmpdir, char *outfile);

#endif
