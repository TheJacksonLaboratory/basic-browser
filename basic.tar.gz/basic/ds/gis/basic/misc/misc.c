#include "misc.h"

#define min(x,y) ((x)<(y)?(x):(y))
#define max(x,y) ((x)>(y)?(x):(y))

int intv_to_seq(char* infile, char* outfile, int chromlen) {
	int32_t start, end, val;
	int16_t *arr = (int16_t*) malloc(chromlen*sizeof(int16_t));
	char buffer[500];
	FILE *fin, *fout;

	int32_t i;
	for (i = 0; i < chromlen; i++) arr[i] = 0;

	printf("Reading file '%s' and filling array of length %d...\n", infile, chromlen);
	fin = fopen(infile, "r");
	while (! feof(fin)) {
		fscanf(fin, "%s\n", buffer);
		if (strlen(buffer) == 0) continue; // skip blank line

		sscanf(buffer, "%d\t%d\t%d\n", &start, &end, &val);
		for (i = min(start, end); i <= max(start, end); i++)
			if (i >= 0 && i < chromlen) arr[i] = val;
	}
	fclose(fin);

	printf("Dumping array to file '%s'...\n", outfile);
	fout = fopen(outfile, "w");
	for (i = 0; i < chromlen; i++) fprintf(fout, "%d\n", arr[i]);
	free(arr);
	fclose(fout);

	return 0;
}
