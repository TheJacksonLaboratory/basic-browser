from setuptools import setup, Extension
from os import path

SRC_DIR = 'gis/basic'

_swig_opts = ['-builtin', '-outdir', SRC_DIR]

# C Modules
_ext_mods = [
  Extension('gis.basic._rmq', [path.join(SRC_DIR, 'rmq', _) for _ in
            ('rmq.i', 'rmq_build.c', 'rmq_query.c')],
            swig_opts=_swig_opts,
  ),
  Extension('gis.basic._avg', [path.join(SRC_DIR, 'avg', _) for _ in
            ('avg.i', 'avg_build.c', 'avg_query.c')],
            swig_opts=_swig_opts,
  ),
  Extension('gis.basic._pets', [path.join(SRC_DIR, 'pets', _) for _ in
            ('pets.i', 'pets_create.c', 'pets_query.c')],
            swig_opts=_swig_opts,
  ),
  Extension('gis.basic._xpets', [path.join(SRC_DIR, 'xpets', _) for _ in
            ('xpets.i', 'xpets_create.c', 'xpets_query.c')],
            swig_opts=_swig_opts,
  ),
  Extension('gis.basic._countif', [path.join(SRC_DIR, 'cif', _) for _ in
            ('countif.i', 'cif_construct.c', 'cif_query.c')],
            swig_opts=_swig_opts,
  ),
]

# C++ Modules
_mmap_deps = [path.join(SRC_DIR, '_mmap', f) for f in (
  'extarr.cpp',
  'fosm.cpp',
  'mmap.cpp',
  'pugixml.cpp',
  'test_mm.cpp',
  'utils.cpp',
)]

_ext_mods += [
  Extension('gis.basic._seq', [path.join(SRC_DIR, 'seq', _) for _ in
            ('seq_access.i', 'seq_access.cpp')] + _mmap_deps,
            swig_opts=['-c++'] + _swig_opts,
            language='c++',
  ),
]

_py_mods = [
  'gis.basic.rmq',
  'gis.basic.avg',
  'gis.basic.pets',
  'gis.basic.xpets',
  'gis.basic.countif',
  'gis.basic.seq',
]

setup(
  name         = 'gis-basic-mods',
  version      = '1.0',
  description  = 'Secret data structures for BASIC',
  author       = ['Huy Hoang Do', 'Wang Jianxing'],
  author_email = ['hoangmit@gmail.com', 'wangjianxing@gmail.com'],
  packages     = ['gis', 'gis.basic'], 
  ext_modules  = _ext_mods,
  py_modules   = _py_mods,

  install_requires = [
    'mysql-python',
    'argparse', # backport from python 2.7
    'futures', # backport from python 3.2
    'pygments', # code highlighter
    'django>=1.4,<1.5',
    'pysam', # SAM Tools
    'pyyaml', # YAML
    'South', # automatic django DB sync
    'pymongo', # binding for MongoDB
    'bitarray', # to generate input for sumDS
  ],
)
