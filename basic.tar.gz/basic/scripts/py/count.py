import sys

if __name__ == '__main__':
    counts = []
    prev = None
    for line in sys.stdin:
        arr = line.rstrip().split('\t')
        curr = arr[0]
        if not counts:
            counts = [0] * max(1, len(arr)-1)
        if prev and prev != curr:
            print '%s\t%s'% (prev, '\t'.join(str(_) for _ in counts))
            for i,x in enumerate(arr[1:] or [1]):
                counts[i] = int(x) 
        else:
            for i,x in enumerate(arr[1:] or [1]):
                counts[i] += int(x) 
        prev = curr
    print '%s\t%s'% (prev, '\t'.join(str(_) for _ in counts))
