'''
Reads BAM files and prints out the chrom, pos, and mpos of read1, provided that both ends are mapped.
Read2 entries are all ignored.

This script assumes that for each paired-end tag, there're only two entries created in the BAM file:
read1 and read2.
BAM files use 0-based indexing. Here we convert them to 1-based indexing.

Created on Jul 1, 2011
@author: fabianus
'''
import errno
import pysam
import sys

if __name__ == '__main__':
  if sys.stdin.isatty():
    reads_list = (pysam.Samfile(f, 'rb') for f in sys.argv[1:])
  else:
    reads_list = [pysam.Samfile('-', 'rb')] # read from stdin
  
  for reads in reads_list:
    chroms = reads.getrname
    try:
      for read in reads:
        if read.is_unmapped or read.mate_is_unmapped:
          continue
        if not read.is_read1: continue # only take read1
        chrom = chroms(read.tid)
        if read.is_reverse:
          print '%s\t%d\t%d'% (chrom, read.mpos + 1, read.pos + read.alen)
        else:
          print '%s\t%d\t%d'% (chrom, read.pos + 1, read.mpos + read.alen)
    except IOError as e:
      if e.errno == errno.EPIPE:
        pass
      else:
        raise