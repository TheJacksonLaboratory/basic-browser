'''
Divide files into distinct temporary files,
depending on the value of the given column.
Input is assumed to be tab-separated.

Column number starts from 1.
'''

from fabi.pytools.shell import split_by_col 

if __name__ == '__main__':
  import sys
  colnum = int(sys.argv[1])
  with split_by_col(sys.stdin, colnum, delete=False) as temps:
    for k,v in temps.iteritems():
      print '%s\t%s'% (k,v) # print out tempfile names
