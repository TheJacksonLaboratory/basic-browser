'''
Created on Jan 30, 2012

@author: mulawadifh
'''
from settings import MONGODBS

class BASICollection(object):
    def __init__(self, id_, module='default'):
        self._coll = MONGODBS[module]['table_{0}'.format(id_)]
    
    def meta(self, m=None):
        if not m:
            met = self._coll.find_one({ '_meta': { '$exists': True } })
            return (met or {}).get('_meta', {})
        else:
            met = self._coll.find_one({ '_meta': { '$exists': True } })
            if not met: 
                met = dict(_meta=m)
            else:
                met['_meta'] = m
            self._coll.save(met)

    def _find(self, fun, *args, **kwargs):
        if len(args) >= 1 and 'spec' not in kwargs:
            args[0].update({ '_meta': { '$exists': False } })
        elif 'spec' in kwargs:
            kwargs['spec'].update({ '_meta': { '$exists': False } })
        else:
            args = list(args)
            args.append({ '_meta': { '$exists': False } })
        return getattr(self._coll, fun)(*args, **kwargs)
    
    def find_all(self, *args, **kwargs):
        return self._find('find', *args, **kwargs)

    def find_one(self, *args, **kwargs):
        return self._find('find_one', *args, **kwargs)
    
    def __getattribute__(self, name): # act like pymongo's Collection
        if name in ('meta', '_coll', '_find', 'find_one', 'find_all'):
            return object.__getattribute__(self, name)
        else:
            _coll = object.__getattribute__(self, '_coll')
            return getattr(_coll, name)

    def has_traits(self, *traits):
        meta = self.meta()
        dbtraits = set(meta.get('traits', []))
        for t in traits:
            if not t in dbtraits: return False
        return True