from contextlib import contextmanager
from django.http import HttpResponse
import decimal
import json
import settings

def _params(source, *args):
  CONVERTERS = dict(int=int, float=float, list=list)
  result = list()
  for arg in args:
    arg = arg.split('~')
    key = arg[0]
    conv = CONVERTERS.get(arg[-1], str)
    
    vals = source.getlist(key)
    if len(vals) == 0:
      result.append(None)
    elif len(vals) == 1:
      result.append(conv(vals[0]))
    else:
      result.append([conv(_) for _ in vals] if conv != list else vals)
  return result[0] if len(result) == 1 else result 

def get_params(request, *args):
  return _params(request.GET, *args)

def post_params(request, *args):
  return _params(request.POST, *args)

class _CustomEncoder(json.JSONEncoder):
  def default(self, o):
    if isinstance(o, decimal.Decimal): return float(o)
    return super(_CustomEncoder, self).default(o)

_json_indent=2 if settings.DEBUG else None
_json_separs=None if settings.DEBUG else (',', ':')
@contextmanager
def json_service(request, result, encoder=_CustomEncoder):
  """
  Convenience method to remove boilerplate code.
  It expects there's a parameter 'callback' in the HTTP request.
  At the end of 'with', caller must explicitly return the response.
  """
  response = HttpResponse(mimetype='application/json')
  
  try:
    yield response # given to caller via 'as'
  finally:
    response.write(json.dumps(result, cls=encoder, indent=_json_indent , separators=_json_separs))
    # callback = request.GET.get("callback")
    # response.write("%s(%s)" %(callback, json.dumps(result, cls=encoder, indent=_json_indent , separators=_json_separs)))

@contextmanager
def cookie(request, prefix='gis.basic.public'):
  class CookieWrapper(object):
    def __init__(self, request):
      object.__setattr__(self, "session", request.session)
    def __delattr__(self, key):
      del self.session['%s.%s'% (prefix,key)]
    def __getattr__(self, key):
      return self.session.get('%s.%s'% (prefix,key))
    def __setattr__(self, key, value):
      self.session['%s.%s'% (prefix,key)] = value
    def __contains__(self, key):
      return '%s.%s'% (prefix, key) in self.session
    def __iter__(self):
      l = len(prefix)+1
      for k,v in self.session.iteritems():
        if k.startswith(prefix): yield (k[l:],v)
    def __delitem__(self, key):
      if type(key) == slice: raise Exception("Not implemented.")
      del self.session['%s.%s'% (prefix,key)]
    def __setitem__(self, key, value):
      if type(key) == slice: raise Exception("Not implemented.")
      self.session['%s.%s'% (prefix,key)] = value
      
  """
  Convenience method to access public cookies (doesn't contain sensitive info)
  """
  try:
    yield CookieWrapper(request)
  finally:
    pass