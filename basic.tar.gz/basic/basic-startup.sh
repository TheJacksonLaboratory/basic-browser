#!/bin/bash
clear
export BASIC_DIR=/opt/basic
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$BASIC_DIR/_py/lib/python2.7/site-packages/extsds/
$BASIC_DIR/_py/bin/python $BASIC_DIR/manage.py runserver 0.0.0.0:8000
