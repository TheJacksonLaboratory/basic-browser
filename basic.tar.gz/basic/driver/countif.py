'''
Created on Nov 4, 2010

@author: fabianus
'''
from contextlib import contextmanager
from gis.basic import countif as cif
from os import path
import yaml

class CountIf:
  @staticmethod
  @contextmanager
  def open(ciffile):
    driver = None
    try:
      driver = CountIf(ciffile)
      yield driver
    finally:
      if driver: driver.close()
  
  def __init__(self, ciffile):
    with open(ciffile) as f:
      self.ciffile = yaml.load(f)
    self.handlers = dict()
    self.ratios = self.ciffile.get("__ratios__", {}) # to scale the retrieved values, if necessary
    self.dirname = path.dirname(path.abspath(ciffile))
  
  def query(self, chrom, start, end, thres):
    h = self.handlers.get(chrom, None)
    if not h:
      f = str(path.join(self.dirname, self.ciffile[chrom]))
      h = cif.init(f)
      self.handlers[chrom] = h
    return cif.countif(h, start-1, end-1, thres) * self.ratios.get(chrom, 1)
  
  def close(self):
    for h in self.handlers.itervalues():
      cif.unload(h)
