/**
 * Fabi. Mar 2011.
 */
(function ($) {
  var _drawHLine = $.gis.basic.helpers.plot._drawHLine,
      _drawAnchor = $.gis.basic.helpers.plot._drawTagAnchor;

  var 
    MIN_EXTLEN = 5, // length of tags drawn in number of pixels
    _DEFAULT_GLYPH_HEIGHT = 10,
    _DEFAULT_GLYPH_POSTPAD = 12;
    
  $.widget("gis.ltagtrack", $.gis.b_rowtrack, {

    options: {
      showLabel: false,
      label: '${name}',
      tooltip: '${seq}',
      glyph: {
        colors: "black",
        height: _DEFAULT_GLYPH_HEIGHT,
        prepad: 0,
        postpad: _DEFAULT_GLYPH_POSTPAD,
        hpad: 3, // distance between glyphs (used in intersection)
      },
      minblock: 7, // minimal letter block size (pixel)
      
      asm: null, // required
      acgt_url: null // required
    },
    
    _colors: {
      A: '#0c0',
      C: '#00a',
      G: '#da0',
      T: '#c00',
      N: '#777'
    },
    
    _modParams: function(params) {
      var opts = this.options,
          curSpan = opts.location.end-opts.location.start+1,
          w = opts._canvas.width();
  
      if (w/curSpan >= opts.minblock) params.show_seq = true;
    },
    
    _preprocess: function(items) {
      for (var i in items) {
        var it = items[i];
        it._text = this._makeLabel(it);
        it._tooltip = this._makeLabel(it, this.options.tooltip);
      }
      this.options.glyph.postpad = this.options.showLabel ? _DEFAULT_GLYPH_POSTPAD : 2;
    },

    _prePlot: function(is_quick, callback) {
      var opts = this.options,
          w = opts._canvas.width(),
          curSpan = opts.location.end-opts.location.start+1;
      
      opts._seq = null;
      opts._showseq = (w/curSpan >= opts.minblock);
      
      opts.glyph.height = opts._showseq ? 10 : 6;
      if (is_quick) { // do query only when it's full refresh
        callback();
        return;
      }
      
      $.getJSON(opts.acgt_url, {
        asm: opts.asm,
        chrom: opts.location.chrom,
        start: opts.location.start,
        end: opts.location.end
      }, function(result) {
        if (result.seq != null) opts._seq = result.seq.toUpperCase();
        callback(); // must be included
      });
    },
    
    _printText: function(ctx, blocksize, text, tag, read, x, y) {
      var opts = this.options, p = x,
          colors = read === 1 ? ['#077', '#bee'] : ['#707', '#ebe'];
      for (var i = 0; i < text.length; i++) {
        var c = text[i];

        if (c === '-') {
          ctx.fillStyle = '#777';
        } else if (opts._seq != null && c != opts._seq[tag._i-opts.location.start+i]) {
          ctx.fillStyle = colors[0];
        } else {
          ctx.fillStyle = colors[1];
        }
        
        ctx.fillText(c, p+blocksize/2, 4);
        p += blocksize;
      }
    },
    
    _drawItem: function(canvas, x, y, w, h, tag, colors, c) {
      var opts = this.options,
          curSpan = opts.location.end-opts.location.start+1,
          ctx = canvas.getContext('2d'),
          hRatio = h / 8,
          colors = ['#077', '#707'];

      ctx.save();

      ctx.translate(0, y + h / 2);
      var cstart = c(tag.pos), 
          cend = cstart + Math.max(MIN_EXTLEN, tag.len*w/curSpan)-1,
          prot = (tag.strand === '+') ? [0, 1] : prot = [-1, 0];

      if (opts._showseq) {
        var blocksize = w/curSpan;
        
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '10px bold';
        
        tag._i = tag.pos;
        this._printText(ctx, blocksize, tag.seq, tag, tag.read, cstart, 4);

        if (tag._mate != null) {
          var x = tag._mate.pos-tag.pos-tag.len+1;
          if (x>0) this._printText(ctx, blocksize, Array(x).join('-'), tag, 0, cstart + tag.len*blocksize, 4);
          tag._i = tag._mate.pos;
          this._printText(ctx, blocksize, tag._mate.seq, tag, tag._mate.read, cstart + (tag._mate.pos-tag.pos)*blocksize, 4);
        }
      } else {
        ctx.lineWidth = 1;
        
        ctx.strokeStyle = colors[tag.read-1]; 
        _drawAnchor(ctx, cstart, -3 * hRatio, cend-cstart, 6 * hRatio, prot[0], prot[1]);

        if (tag._mate != null) {
          var x = c(tag._mate.pos);
          ctx.strokeStyle = '#777';
          _drawHLine(ctx, cend, x, 0);

          var cstart_ = x, 
              cend_ = cstart_ + Math.max(MIN_EXTLEN, tag._mate.len*w/curSpan)-1,
              prot_ = (tag._mate.strand === '+') ? [0, 1] : prot_ = [-1, 0];
              
          ctx.strokeStyle = colors[tag._mate.read-1];
          _drawAnchor(ctx, cstart_, -3 * hRatio, cend_-cstart_, 6 * hRatio, prot_[0], prot_[1]);
        }
      }

      if (this.options.showLabel) {
        // 5. write symbol/accession
        ctx.fillStyle = 'blue'; // this._getColor(colors, 'text', tag);
        ctx.font = 'normal 9px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(tag._text, Math.max(1, cstart), 6 * hRatio + 6);
      }
      
      ctx.restore();
    },

    _measureWidth: function(canvas, w, tag, c) {
      var ctx = canvas.getContext("2d"),
          opts = this.options,
          curSpan = opts.location.end-opts.location.start+1,
          cstart, cend;
      
      cstart = c(tag.pos);
      cstart = Math.max(1, cstart);

      if (tag._mate != null) {
        cend = cstart + Math.max(MIN_EXTLEN, (tag._mate.pos+tag._mate.len-tag.pos)*w/curSpan)-1;
      } else {
        cend = cstart + Math.max(MIN_EXTLEN, tag.len*w/curSpan)-1;
      }
      
      cend = Math.min(w, cend);
      
      var actualWidth = Math.max(cend - cstart, this.options.showLabel ? ctx.measureText(tag._text).width : 0);
      return { start: cstart, end: cstart + actualWidth };
    }
  });
  
})(jQuery);