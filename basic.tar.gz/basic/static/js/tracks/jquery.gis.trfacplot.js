(function ($) {
  var _drawHLine = $.gis.basic.helpers.plot._drawHLine,
      _drawAnchor = $.gis.basic.helpers.plot._drawClusterAnchor;

  var _getColor = function(colors, comp, item) { // comp <- (line|outline|fill)
    if (colors == null) return 'black'; // paranoid check
    var defaultValue = colors._ || 'black', // if specific type is not found, use wildcard "_"
        c = colors[comp] || defaultValue;
    
    if (!_.isFunction(c)) return c;
    
    var args = $.extend({
      comp: comp, // component type
      element: item,
      
      cluster: item, // for backward compatibility
      tag: item // for backward compatibility
    });
    return c(args) || defaultValue; // in case the function doesn't return valid value
  }

  function _drawconnector(canvas, y, w, h, c) {
    var ctx = canvas.getContext("2d");
    
    ctx.save();
    ctx.translate(0, y + h / 2);
    ctx.strokeStyle = "#ccc";
    ctx.lineWidth = 1;
    _drawHLine(ctx, 0,w, 0);
    ctx.restore();
  }
  
  function _drawtrfac(canvas, x, y, w, h, trfac, colors, c) {
    var ctx    = canvas.getContext("2d"),
        hRatio = h / 8,
        //text   = _makeText(trfac),
        cstart = Math.max(1, c(trfac.start)),
        cend   = Math.min(w, c(trfac.end));

    ctx.save();
    ctx.translate(0, y + h / 2);
    ctx.lineWidth = 1;

    ctx.strokeStyle = _getColor(colors, "outline", trfac);
    ctx.fillStyle = _getColor(colors, "fill", trfac);

    var prot = 0;
    if (trfac.strand == "+") prot = 1; else if (trfac.strand == "-") prot = -1;
    _drawAnchor(ctx, cstart, -3 * hRatio, cend-cstart, 6 * hRatio, prot, prot);
    ctx.restore();
  };

  function _addLinks(parent, canvas, y, w, h, postpad, trfac, c) {
    // determine which part of canvas will be used to draw given trfac
    var ctx  = canvas.getContext("2d"),
        text = _makeText(trfac);

    var cstart = Math.max(1, c(trfac.start)),
        cend   = Math.min(w, c(trfac.end)),
        actualWidth = Math.max(cend - cstart, ctx.measureText(text).width),
        left = cstart;

    var elem = $("<div>").css({
      position: "absolute",
      top: y,
      left: left+10,
      //"background-color": "rgba(255, 255, 0, 0.3)",
      width: actualWidth,
      height: h + postpad,
      cursor: "pointer"
    }).attr({
      title: text
    }).appendTo(parent);
    return elem;
  };

  function _addLabelTooltip(parent, y, w, h, postpad, text) {
    var elem = $("<div>").css({
      position: "absolute",
      top: y,
      left: 1,
      width: w,
      height: h + postpad
    }).attr({ title: text }).addClass('rowLabel').appendTo(parent);
  };

  function _createLayer(canvasHolder) {
    var canvas = canvasHolder.find(">canvas");
    var w = BASIConst.flot.labelWidth;
    return $("<div>")
      .addClass("ui-widget ui-widget-content")
      .css({
        position: "absolute",
        width: w-5,
        height: canvasHolder.parent().height(),
        top: canvas.position().top-4,
        left: canvas.position().left-w,
        margin: 0,
        "overflow-x": "hidden",
        "overflow-y": "hidden",
        border: 'none'
      }).appendTo(canvasHolder);
  };

  function _addLabel(parent, y, h, postpad, text) {
    var elem = $("<div>").css({
      position: "absolute",
      top: y+2,
      right: "0.5em",
      height: h + postpad,
      "font-size": "8px",
      color: "#1C94C4",
      'white-space': 'nowrap'
    }).attr({
      title: text
    }).html(text).appendTo(parent);
    return elem;
  };
  
  function _createLinkLayer(canvasHolder) {
    var canvas = canvasHolder.find(">canvas");
    return $("<div>").css({
      position: "absolute",
      top: canvas.position().top,
      left: canvas.position().left,
      margin: 0
    }).appendTo(canvasHolder);
  };

  $.fn.trfacplot = function (opts) {
    opts = $.extend({}, $.fn.trfacplot.defaults, opts);

    var trfacLinks = []; // returned at the end of function; so this plugin can't be chained
    var colors = {};
    if (_.isObject(opts.colors)) {
      colors = opts.colors; // if head/tail/line is missing, wildcard/default color will be used (see _getColor)
    } else { // either string or function
      colors = { _: opts.colors }; // set the wildcard
    }

    this.each(function () {
      var data = opts.data,
          prepad = opts.prepad,
          postpad = opts.postpad,
          h = opts.height,
          labelLayer = null;

      if (!(opts.showLabel || opts.showSize || opts.showPos)) prepad = postpad = 0;

      var canvasHolder = $(this),
          canvas = $.gis.basic.helpers.plot._createCanvas(opts, canvasHolder),
          w = canvas.width();

      // avoid re-creating layers if they're already present
      labelLayer = canvasHolder.data("labelLayer");
      if (!labelLayer) {
        labelLayer = _createLayer(canvasHolder);
        canvasHolder.data("labelLayer", labelLayer);
      }
      
      labelLayer.css({
        height: canvasHolder.height()-5
      });

      linkLayer = canvasHolder.data("linkLayer");
      if (!linkLayer) {
        linkLayer = _createLinkLayer(canvasHolder);
        canvasHolder.data("linkLayer", linkLayer);
      }

      // check if full draw is requested
      canvasHolder.data("trfacRows", {});
      labelLayer.empty();
      linkLayer.empty();

      var ratio = w/(opts.end - opts.start+1),
          _c = function(x1) {
                 // convert genome location to canvas coordinate
        return (x1 - opts.start) * ratio;
               };

      canvas.hide();
      
      // determine rows
      var trfacnamelist = [],
          trfacnamedict = {},
          rowcount = 0;
      
      for (var i in data) {
        var trfac = data[i],
            name = trfac.name;
        
        if (trfacnamedict[name] == null) {
          trfacnamelist.push(name);
          trfacnamedict[name] = true;
          rowcount++;
        }
      }

      // resize canvas and redraw
      var canvasEl = canvas.get(0);
      $(canvasEl).attr({
        height: (h + prepad + postpad) * (rowcount + 2)
      });
      
      sortednames = trfacnamelist.sort();
      rowmapper = {};
      for (var i in sortednames) {
        var name = sortednames[i];
        rowmapper[name] = i;
        _addLabel(labelLayer, i * (h + postpad) + prepad * (i + 1), h, postpad, name);
        _drawconnector(canvasEl, i * (h + postpad) + prepad * (i + 1), w, h, _c);
        if (!opts.quick) _addLabelTooltip(linkLayer, i * (h + postpad) + prepad * (i + 1), w, h, postpad, name);
      }

      for (var i in data) {
        var trfac = data[i], 
            r = rowmapper[trfac.name];
        _drawtrfac(canvasEl, 0, r * (h + postpad) + prepad * (r + 1), w, h, trfac, colors, _c);
      }
      
      canvas.show();
    });

    return trfacLinks;
  };

  $.fn.trfacplot.defaults = {
    colors: "black",
    height: 10,
    prepad: 0,
    postpad: 0,
    quick: false,
    
    showSize: true,
    showPos: true,
    showLabel: true,
    
    // if true, layers are not drawn
    // the following are required
    data: null,
    start: 0,
    end: 0
  };
})(jQuery);