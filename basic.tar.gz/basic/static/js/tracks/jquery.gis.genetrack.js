/**
 * Fabi. Aug 2010.
 */
(function ($) {
  function _drawArrowHLine(ctx, x1, x2, y, dir, hRatio, quick) {
    ctx.save();
    ctx.beginPath();

    // main line
    ctx.moveTo(x1, y);
    ctx.lineTo(x2, y);

    // arrows -- draw only when we're not in quickdraw mode
    if (! quick) {
      var delta = -dir * hRatio * 2;
      for (var i = x1 + hRatio * 6; i < x2 - hRatio * 6; i += hRatio * 6) {
        ctx.moveTo(i, y);
        ctx.lineTo(i + delta, y - delta);
        ctx.moveTo(i, y);
        ctx.lineTo(i + delta, y + delta);
      }
    }

    ctx.stroke();
    ctx.closePath();
    ctx.restore();
  };

  $.widget("gis.genetrack", $.gis.b_rowtrack, {
    options: {
      label: '${sym}',
      tooltip: '${name}',
      glyph: {
        colors: "black",
        height: 8,
        prepad: 4,
        postpad: 10,
        clickable: true
      }
    },
    
    _preprocess: function(items) {
      var self = this;
      _.each(items, function(it) {
        it._text = self._makeLabel(it);
        it._tooltip = self._makeLabel(it, self.options.tooltip);
      });
    },

    _drawItem: function(canvas, x, y, w, h, gene, colors, c, quick) {
      var ctx = canvas.getContext("2d"),
          hRatio = h / 8,
          color = gene.strand == "+" ? "rgb(0,128,0)" : "blue",
          dir = gene.strand == "+" ? 1 : -1,
          cstart = Math.max(1, c(gene.start)),
          cend = Math.min(w, c(gene.end));

      ctx.save();

      ctx.clearRect(cstart, y, cend - cstart, h);
      ctx.translate(0, y + h / 2);
      ctx.lineWidth = 1;

      ctx.beginPath();
      ctx.moveTo(cstart, 0);
      ctx.lineTo(cend, 0);
      ctx.strokeStyle = color;
      ctx.stroke();
      ctx.closePath();

      // 1. draw exons (grey)
      ctx.fillStyle = "rgb(208,208,208)";
      _.each(gene.exons, function(ex) {
        var cx0 = c(gene.start + ex[0]),
            cx1 = c(gene.start + ex[1]);
        if (cx1<=0 || cx0>w) return;
        ctx.fillRect(cx0, -2 * hRatio, cx1 - cx0, 4 * hRatio);
        ctx.strokeRect(cx0, -2 * hRatio, cx1 - cx0, 4 * hRatio);
      });

      // 2. draw CDS (solid blue/green)
      ctx.fillStyle = color;
      var cx0 = Math.max(1, c(gene.cds_start)),
          cx1 = Math.min(c(gene.cds_end), w);
      ctx.fillRect(cx0, -4 * hRatio, cx1 - cx0, 8 * hRatio);
      
      if (gene.domains != null) {
        ctx.fillStyle = 'orange';
        ctx.strokeStyle = color;
        _.each(gene.domains, function(dom) {
          var dname = dom[0],
              cx0 = c(dom[1]),
              cx1 = c(dom[2]);
          
          if (cx1 - cx0 >= 5) {
            ctx.fillRect(cx0, -4 * hRatio, cx1 - cx0, 8 * hRatio);
            ctx.strokeRect(cx0, -4 * hRatio, cx1 - cx0, 8 * hRatio);
          }
        });
      }

      // 3. draw introns (arrowed lines) 
      _.each(gene.introns, function(intr) {
        var cx0 = c(gene.start + intr[0]),
            cx1 = c(gene.start + intr[1]);
            
        if (cx1<=0 || cx0>w) return; // don't draw if they're outside drawing area
        if (cx1 - cx0 <= 2) return; // don't draw intron if it's less than 2px wide
        ctx.clearRect(cx0, -5 * hRatio, cx1 - cx0, 10 * hRatio);
        _drawArrowHLine(ctx, cx0, cx1, 0, dir, hRatio, quick);
      });

      // 4. draw arrow head (not part of genes)
      var delta = 3 * hRatio * dir,
          cx = 0;
      ctx.beginPath();
      if (gene.strand == "+") {
        ctx.moveTo(cend, 0);
        cx = cend + delta;
      } else {
        ctx.moveTo(cstart, 0);
        cx = cstart + delta;
      }
      ctx.lineTo(cx + delta, 0);
      ctx.lineTo(cx, delta);
      ctx.moveTo(cx + delta, 0);
      ctx.lineTo(cx, -delta);
      ctx.strokeStyle = color;
      ctx.stroke();
      ctx.closePath();

      // 5. write symbol/accession
      ctx.fillStyle = this._getColor(colors, "text", gene) || 'black';
      ctx.font = "normal 9px sans-serif";
      ctx.fillText(gene._text, Math.max(0, c(gene.start)), 6 * hRatio + 6);

      // 6. write annotations
      ctx.font = "bold 8px sans-serif";
      if (gene.icons) {
        for (var i in gene.icons) {
          var icon = gene.icons[i];
          if (icon[1] == "+") {
            ctx.fillStyle = "black";
            ctx.fillText(icon[0], cstart + 6 * i, -6 * hRatio + 1);
          } else if (icon[1] == "-") {
            ctx.fillStyle = "#ccc";
            ctx.fillText(icon[0], cstart + 6 * i, -6 * hRatio + 1);
          }
        }
      }

      ctx.restore();
    },
    
    _measureWidth: function(canvas, w, gene, c) {
      // determine which part of canvas will be used to draw given gene
      var ctx = canvas.getContext("2d"),
          cstart = Math.max(1, c(gene.start)),
          cend = Math.min(w, c(gene.end));
      
      var txt = gene.sym;
      var actualWidth = Math.max(cend - cstart, ctx.measureText(txt).width);
      return {
        start: cstart,
        end: cstart + actualWidth
      };
    },

    _addLinks: function(parent, canvas, y, w, h, postpad, gene, c) {
      var ctx = canvas.getContext("2d"),
          cstart = Math.max(1, c(gene.start)),
          cend = Math.min(w, c(gene.end)),
          actualWidth = Math.max(cend - cstart, ctx.measureText(gene.sym).width);

      var elem = $("<div>").css({
        position: "absolute",
        top: y,
        left: cstart,
        //"background-color": "rgba(255, 0, 0, 0.4)",
        width: actualWidth,
        height: h + postpad,
        cursor: "pointer"
      }).attr({
        title: gene._tooltip
      }).appendTo(parent);
      return elem;
    }
  });
})(jQuery);