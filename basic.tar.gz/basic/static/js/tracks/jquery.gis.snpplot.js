(function ($) {
  var _drawHLine = $.gis.basic.helpers.plot._drawHLine;

  function _getColor(colors, comp, snp) { // comp <- (line|outline|fill)
    if (colors == null) return "black"; // paranoid check
    var def = colors._ || "black", // if specific type is not found, use wildcard "_"
        c = colors[comp] || def;
    if (_.isFunction(c)) {
      var args = $.extend({
        comp: comp, // component type
        cluster: snp
      });
      return c(args) || def; // in case the function doesn't return valid value
    } else
    return c;
  }
  
  function _drawConnector(canvas, y, w, h, c) {
    var ctx = canvas.getContext("2d");
    ctx.save();
    ctx.translate(0, y + h / 2);
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#ccc";
    _drawHLine(ctx, 0,w, 0);
    ctx.restore();
  }
  
  function _rgb(r, g, b, a) {
    return 'rgb('+r+','+g+','+b+')';
  }
  
  function _hsv2rgb(h, s, v){
    var r = 0, g = 0, b = 0,
        i = Math.floor(h * 6),
        f = h * 6 - i,
        p = v * (1 - s),
        q = v * (1 - f * s),
        t = v * (1 - (1 - f) * s);

    switch(i % 6){
      case 0: r = v, g = t, b = p; break;
      case 1: r = q, g = v, b = p; break;
      case 2: r = p, g = v, b = t; break;
      case 3: r = p, g = q, b = v; break;
      case 4: r = t, g = p, b = v; break;
      case 5: r = v, g = p, b = q; break;
    }

    return 'rgb('+Math.round(r*255)+','+Math.round(g*255)+','+Math.round(b*255)+')';
  }

  function _plotHeatmap(canvas, y, h, map) {
    var ctx    = canvas.getContext("2d"),
        hRatio = h / 8;

    ctx.save();
    ctx.translate(0, y + h / 2);
    ctx.strokeStyle = '';
    for (var x in map) {
      if (map[x] === 0) continue;
      ctx.fillStyle = _hsv2rgb(0, // blue (decrease)--> red
                               0, // washed-out (increase)--> fullcolor
                               Math.max(0.4, 0.9 - map[x] / 25.0)); // 1=bright, 0=black
      ctx.fillRect(x, -3 * hRatio, 1, 6 * hRatio);
    }
    ctx.restore();
  };
  
  function _plotNonsynSNPs(canvas, y, h, nonsyns, c, ratio) {
    var ctx    = canvas.getContext("2d"),
        hRatio = h / 8;

    ctx.save();
    ctx.translate(0, y + h / 2);
    ctx.strokeStyle = '';
    
    for (var i in nonsyns) {
      var nonsyn = nonsyns[i];
      ctx.fillStyle = nonsyn.damaging ? 'red' : 'orange';
      ctx.fillRect(c(nonsyn.start)-1, -3 * hRatio, Math.max(1, ratio)+1, 6 * hRatio); // 3px wide
    }
    ctx.restore();
  };

  function _addLinks(parent, canvas, y, w, h, postpad, gspan, snp, c) {
    // determine which part of canvas will be used to draw given snp
    var text = snp.chrom + ':' + snp.pos + " [snp=" + snp.val + "|ref=" + (snp.refbase || '') + ']',
        cstart = Math.max(1, c(snp.pos)),
        cend = Math.min(w, cstart+w/gspan);

    var elem = $("<div>").css({
      position: "absolute",
      top: y,
      left: cstart-1,
      //"background-color": "rgba(255, 255, 0, 0.3)",
      width: Math.max(2, cend-cstart)+2,
      height: h + postpad,
      cursor: "pointer"
    }).attr({
      title: text
    }).addClass('snp').hover(
      function () { $(this).css({ 'background-color': '#080' }); }, 
      function () { $(this).css({ 'background-color': '' });    }
    ).appendTo(parent);
    return elem;
  };

  function _createLabelLayer(canvasHolder) {
    var canvas = canvasHolder.find(">canvas");
    var w = BASIConst.flot.labelWidth;
    return $("<div>")
      .addClass("ui-widget ui-widget-content")
      .css({
        position: "absolute",
        width: w-5,
        height: canvas.height(),
        top: canvas.position().top-5,
        left: canvas.position().left-w,
        margin: 0,
        "overflow-x": "hidden",
        "overflow-y": "hidden",
        "white-space": "nowrap",
        "font-weight": "bold",
        border: 'none'
      }).appendTo(canvasHolder);
  };

  function _createLinkLayer(canvasHolder) {
    var canvas = canvasHolder.find(">canvas");
    return $("<div>").css({
      position: "absolute",
      top: canvas.position().top,
      left: canvas.position().left,
      margin: 0
    }).appendTo(canvasHolder);
  };

  function _addLabel(parent, y, h, postpad, text) {
    var elem = $("<div>").css({
      position: "absolute",
      top: y+5,
      right: "0.3em",
      height: h + postpad,
      "font-size": "12px",
      color: "#1C94C4"
    }).attr({ title: text }).html(text).appendTo(parent);
    return elem;
  };

  function _addLabelTooltip(parent, y, w, h, postpad, text) {
    $("<div>").css({
      position: "absolute",
      top: y,
      left: 1,
      width: w-15,
      height: h + postpad
    }).attr({ title: text }).addClass('rowLabel').appendTo(parent);
  };
  
  function _setSNPValue(snp) {
    // determine the value of SNP on the fly
    var acgt = ['A', 'C', 'G', 'T'],
        reads = snp.reads,
        total = reads.A + reads.C + reads.G + reads.T,
        vals = []; // SNP value
    
    for (var i in acgt) {
      var letter = acgt[i],
          freq = reads[letter];

      if (letter == (snp.refbase || '').toUpperCase()) 
        continue; // naturally, we ignore the letter which is equal to refbase
      
      if (freq > total/2) {
        vals = [letter + '(' + Math.round(freq*100/total) + '%)'];
        break;
      } else if (freq >= 2) {
        vals.push(letter.toLowerCase());
      }
    }
    return vals.join(',');
  };
  
  $.fn.snpplot = function (opts) {
    opts = $.extend({}, $.fn.snpplot.defaults, opts);
    _options = opts; // global var

    var snpLinks = []; // returned at the end of function; so this plugin can't be chained
    var colors = {};
    if (_.isObject(opts.colors)) {
      colors = opts.colors; // if head/tail/line is missing, wildcard/default color will be used (see _getColor)
    } else { // either string or function
      colors = { _: opts.colors }; // set the wildcard
    }

    this.each(function () {
      var data = opts.data,
          prepad = opts.prepad,
          postpad = opts.postpad,
          h = opts.height,
          labelLayer = null,
          linkLayer = null;

      var canvasHolder = $(this),
          canvas = $.gis.basic.helpers.plot._createCanvas(opts, canvasHolder),
          w = canvas.width();

      // avoid re-creating layers if they're already present
      labelLayer = canvasHolder.data("labelLayer");
      if (!labelLayer) {
        labelLayer = _createLabelLayer(canvasHolder);
        canvasHolder.data("labelLayer", labelLayer);
      }
      
      linkLayer = canvasHolder.data("linkLayer");
      if (!linkLayer) {
        linkLayer = _createLinkLayer(canvasHolder);
        canvasHolder.data("linkLayer", linkLayer);
      }
      
      // check if full draw is requested
      canvasHolder.data("snpRows", {});
      labelLayer.empty();
      linkLayer.empty();

      var ratio = w/(opts.end - opts.start+1),
          _c = function(x1) {
                 // convert genome location to canvas coordinate
                 return (x1 - opts.start) * ratio;
               };

      canvas.hide();
      
      // determine rows
      var snpnamelist = [],
          rowcount = 0;
      
      for (var i in data.map) {
        snpnamelist.push(i);
          rowcount++;
        }

      // resize canvas and redraw
      var canvasEl = canvas.get(0);
      $(canvasEl).attr({ height: (h + prepad + postpad) * (rowcount + 2) });

      labelLayer.css({
        height: canvas.height()-5
      });
      
      sortednames = snpnamelist.sort();
      rowmapper = {};
      for (var i in sortednames) {
        var group = sortednames[i];
        rowmapper[group] = i;
        _addLabel(labelLayer, i * (h + postpad) + prepad * (i + 1), h, postpad, group);
        _drawConnector(canvasEl, i * (h + postpad) + prepad * (i + 1), w, h, _c);
        if (!opts.quick) _addLabelTooltip(linkLayer, i * (h + postpad) + prepad * (i + 1), w, h, postpad, name);
      }

      for (var group in data.map) {
        var r = rowmapper[group];
        _plotHeatmap(canvasEl, r * (h + postpad) + prepad * (r + 1), h, data.map[group]);
      }
      
      _plotNonsynSNPs(canvasEl, prepad, h, data['pgs.nonsyns'] || [], _c, ratio);
      
      var gspan = opts.end - opts.start + 1;
      for (var i in data.entries) {
        var entry = data.entries[i],
            grouplist = entry.groups;
        
        for (var j in grouplist) {
          var group = grouplist[j],
              r = rowmapper[group.name];

          group.refbase = group.refbase || entry.refbase;
          var val = _setSNPValue(group);
          
          if (!opts.quick) {
            var snp = {
              chrom: entry.chrom, pos: entry.pos, val: val, refbase: entry.refbase  
            };
            var link = _addLinks(linkLayer, canvasEl, r * (h + postpad) + prepad * (r + 1), w, h, postpad, gspan, snp, _c);
            snpLinks.push([entry, link]);
          }
        }
      }
      
      canvas.show();
    });

    return snpLinks;
  };

  $.fn.snpplot.defaults = {
    colors: "black",
    height: 20,
    prepad: 0,
    postpad: 0,
    quick: false,
    
    // if true, layers are not drawn
    // the following are required
    data: null,
    acgt: null, // reference sequence (type=dictionary of {position->baseletter})
    start: 0,
    end: 0
  };
})(jQuery);