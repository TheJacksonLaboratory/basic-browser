/**
 * Indicates the area in genome currently viewed.
 * Fabi. Jul 2010.
 */
(function ($) {
  $.widget('gis.chromview', $.ui.mouse, {
    _colorCodes: {
      gpos100: 'rgb(0,0,0)',
      gpos: 'rgb(0,0,0)',
      gpos75: 'rgb(130,130,130)',
      gpos66: 'rgb(160,160,160)',
      gpos50: 'rgb(200,200,200)',
      gpos33: 'rgb(210,210,210)',
      gpos25: 'rgb(200,200,200)',
      gvar: 'rgb(220,220,220)',
      gneg: 'rgb(255,255,255)',
      acen: 'rgb(217,47,39)',
      stalk: 'rgb(100,127,164)'
    },
    _chromSize: {},

    options: {
      bands: null, // required
      chrom: null, // required
      min: 1,
      max: 100,
      start: 1,
      end: 100,
      height: 40,
      color: 'black',
      selectorVisible: true,
      position: null
    },
    _autoId: 0,

    _init: function () {
      this._mouseInit();
    },
    destroy: function () {
      this._mouseDestroy();
    },

    _createContent: function(trackId) {
      var opts = this.options,
          track = opts._track;

      track //.bind('contextmenu', function (e) { return false; }) // disable context menu
        .addClass('ui-dialog ui-widget-content')
        .css({
          position: 'relative',
          width: '100%',
          border: 'none'
        });
      
      var content = $('<div>').addClass('ui-dialog-content ui-widget-content')
      .css({
        overflow: 'hidden'
      }).disableSelection().appendTo(track);
        
      var canvas = $('<div>').attr({ id: trackId + '_canvas' }).css({
        'margin-top': '3px',
        height: this.options.height-3
      }).appendTo(content);
      
      return {
        content: content,
        canvas: canvas
      };
    },
    
    hresize: function() {
      var el = this.element;
      el.css({ width: '100%' });
      this._drawPlot();
    },

    _drawPlot: function () {
      this.__drawPlot();

      var opts = this.options,
          track = opts._track,
          canvas = opts._canvas;

      var min = opts.min,
          max = opts.max,
          w = this.rightDragBound() - this.leftDragBound(),
          skip = (max - min) * 1.0 / w;

      var l = Math.round((this.options.start - min) / skip),
          r = Math.round((this.options.end - min) / skip);

      opts._select.css({
        left: this.leftDragBound() + l,
        width: r - l
      });
    },

    __drawPlot: function () {
      var opts = this.options,
          track = opts._track,
          canvas = opts._canvas;

      var min = opts.min,
          max = opts.max,
          w = opts._colors[opts.chrom].length,
          skip = (max - min) / w;

      var ratio2 = (max - min) / this._chromSize[opts.chrom],
          l2 = w * min / this._chromSize[opts.chrom];

      var colcodes = [],
          xvalues = [];
      
      for (var i in this._colorCodes) {
        var ccode = this._colorCodes[i],
            colors = opts._colors[opts.chrom],
            values = [];
        colcodes.push(ccode);
        for (var j = 0; j < w; j++) {
          values.push([j * skip + min, colors[Math.round(l2 + j * ratio2)] == i ? 1 : 0]);
        }
        xvalues.push(values);
      }

      $.plot(canvas, xvalues, {
        grid: { 
          tickColor: '#ccc',
          borderWidth: 1,
          reserveSpace: true
        },
        xaxis: {
          min: min,
          max: max,
          tickDecimals: 0,
          minTickSize: 1,
          tickFormatter: function (val, axis) {
            return BASIC_intComma(val);
          }
        },
        yaxis: {
          labelWidth: BASIConst.flot.labelWidth,
          ticks: 0,
          max: 1
        },
        series: {
          lines: {
            lineWidth: 0,
            fill: 0.6,
            steps: true
          }
        },
        colors: colcodes
      });
    },

    _create: function () {
      var opts = this.options;
      opts._track = this.element;
      
      var trackId = opts._track.attr('id'),
          xyz = this._createContent(trackId);

      opts._canvas = xyz.canvas;
      opts._content = xyz.content;

      // selector
      opts._select = $('<div>').appendTo(opts._content)
      .addClass('ui-corner-all').css({
        position: 'absolute',
        border: '2px solid ' + opts.color,
        opacity: 1,
        top: opts._canvas.position().top+2,
        height: opts._content.height()-4
      }).hide();

      $('<span>').appendTo(opts._select);
      
      if (opts.selectorVisible) opts._select.show();

      this._translate_chrome_bands();
    },

    _translate_chrome_bands: function () {
      var opts = this.options,
          w = this.rightDragBound() - this.leftDragBound();

      opts._colors = {}; // these values are only computed once
      
      for (var i in opts.bands) {
        var band = opts.bands[i],
            ratio = w / band.size; // screen size/real size
        this._chromSize[band.name] = band.size;

        var colors = opts._colors[band.name] = [];
        for (var j = 0; j < w; j++) colors.push(0); // fill with zeroes
        // fill with colors
        for (var k in band.p) { // P part of chrom
          var p = band.p[k];
          for (var x = Math.round(p.l * ratio); x <= Math.round(p.r * ratio); x++)
          colors[x] = p.c; // color code
        }
        for (var k in band.q) { // Q part of chrom
          var q = band.q[k];
          for (var x = Math.round(q.l * ratio); x <= Math.round(q.r * ratio); x++)
          colors[x] = q.c; // color code
        }
      }
    },
    
    leftDragBound: function () {
      return BASIConst.flot.labelWidth + 17; // magic number
    },

    rightDragBound: function () {
      return this.options._content.width() + 5; // magic number
    },

    _mouseStart: function (e) {
      var opts = this.options,
          cont = opts._content;
      var x = e.pageX - cont.offset().left;
      if (x < this.leftDragBound() || x > this.rightDragBound()) return;

      opts._select.show();

      this.xStart = x; // in basepairs
      opts._select.css({
        'background-color': 'whiteSmoke',
        opacity: 0.4
      }).find('span').show();

      this._trigger('start', e, {
        self: this.element,
        start: this.options.start,
        end: this.options.end
      });
    },

    _mouseDrag: function (e) {
      if (!this.xStart) return;
      var opts = this.options,
          cont = opts._content;

      var start = Math.min(e.pageX - cont.offset().left, this.xStart),
          end = Math.max(e.pageX - cont.offset().left, this.xStart);

      var lBound = this.leftDragBound(),
          rBound = this.rightDragBound();

      start = Math.max(start, lBound);
      end = Math.min(end, this.rightDragBound());

      var p = opts.min,
          q = opts.max,
          skip = (q - p) / (rBound - lBound); // basepairs per pixel
      
      // in base pairs
      var bpStart = p + Math.round((start - lBound) * skip);
      var bpEnd = p + Math.round((end - lBound) * skip);

      opts.start = bpStart;
      opts.end = bpEnd;

      opts._select.css({
        top: opts._canvas.position().top,
        left: start,
        width: (end - start)
      }).find('>span').css({
        'font-weight': 'bold'
      }).position({
        my: 'center',
        at: 'center',
        of: opts._select
      }).text(BASIC_intComma(bpEnd - bpStart + 1));

      this._trigger('select', e, {
        self: this.element,
        start: bpStart,
        end: bpEnd
      });
    },

    _mouseStop: function (e) {
      if (!this.xStart) return;
      var opts = this.options;
      opts._select.css({
        'background-color': '',
        opacity: 1
      }).find('span').hide();

      if (!opts.selectorVisible) opts._select.hide();

      this.xStart = null;
      this._drawPlot(opts._track, opts._canvas);

      this._trigger('stop', e, {
        self: this.element,
        start: this.options.start,
        end: this.options.end
      });
    },

    values: function () {
      return {
        start: this.options.start,
        end: this.options.end
      };
    },

    limits: function () {
      return {
        start: this.options.min,
        end: this.options.max
      };
    },

    setValues: function (min, max) {
      var opts = this.options;
      opts.start = Math.max(opts.min, min);
      opts.end = Math.min(opts.max, max);
      this._drawPlot(opts._track, opts._canvas);
    },

    setLimits: function (min, max) {
      var opts = this.options;
      opts.min = opts.start = min;
      opts.max = opts.end = max;
      this._drawPlot(opts._track, opts._canvas);
    },

    setChrom: function (chrom) { // must be called before setLimits
      var opts = this.options;
      opts.chrom = chrom;
    }
  });
})(jQuery);