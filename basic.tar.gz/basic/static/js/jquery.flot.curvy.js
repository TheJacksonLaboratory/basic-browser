(function ($) {
  var options = {
      strokeColor: null,
      opacity: 0
//    curvy: true // this must be set for the plugin to take effect
  };

  function drawEllipse(ctx, x, y, w, h, curveUp) {
    var kappa = .5522848;
        ox = (w / 2) * kappa, // control point offset horizontal
        oy = (h / 2) * kappa, // control point offset vertical
        xe = x + w,           // x-end
        ye = y + h,           // y-end
        xm = x + w / 2,       // x-middle
        ym = y + h / 2;       // y-middle

    ctx.beginPath();
    if (curveUp) {
      ctx.moveTo(x, ym);
      ctx.bezierCurveTo(x, ym - oy, xm - ox, y, xm, y);
      ctx.bezierCurveTo(xm + ox, y, xe, ym - oy, xe, ym);
    } else {
      ctx.moveTo(xe, ym);
      ctx.bezierCurveTo(xe, ym + oy, xm + ox, ye, xm, ye);
      ctx.bezierCurveTo(xm - ox, ye, x, ym + oy, x, ym);
    }
    ctx.closePath();
  }
  
  function init(plot) {
    plot.hooks.processRawData.push(function(plot, series, data, datapoints) {
      var c = plot.getOptions().curvy;
      if (!c) return;

      datapoints.format = [
        { x: true, number: true, required: true },
        { x: true, number: true, required: true },
        { y: true, number: true, required: true }
      ];
    });

    plot.hooks.processDatapoints.push(function(series, datapoints) {
      var hazGrey = false;
      for (var s in series) {
        var data = series[s].data;
        for (var i in data) {
          var val = data[i][2];
          if (val < 0) {
            hazGrey = true;
            break;
          }
        }
        if (hazGrey) break;
      }
      if (! hazGrey) {
        var yaxis = plot.getAxes().yaxis;
        yaxis.min = 0;
        yaxis.datamin = 0;
      }
    });

    plot.hooks.draw.push(function(plot, ctx) {
      var c = plot.getOptions().curvy;
      if (!c) return;

      var series = plot.getData(),
          plotOffset = plot.getPlotOffset(),
          defStrokeCol = plot.getOptions().strokeColor,
          opacity = plot.getOptions().opacity;
      
      for (var s in series) {
        var col = series[s].color,
            strokeCol = series[s].strokeColor || defStrokeCol;
            data = series[s].data;
        
        ctx.save();
        ctx.translate(plotOffset.left, plotOffset.top);
  
        var xaxis = plot.getAxes().xaxis,
            yaxis = plot.getAxes().yaxis;
        
        ctx.rect(0, 0, xaxis.p2c(xaxis.max), yaxis.p2c(yaxis.min));
        ctx.clip();
        var yaxis_zero = yaxis.p2c(0);

        ctx.fillStyle = $.color.parse(col).add('a', opacity-1).toString();

        for (var i in data) {
          var l = xaxis.p2c(data[i][0]),
              r = xaxis.p2c(data[i][1]),
              x = (l+r)/2,
              val = Math.abs(data[i][2]),
              h = yaxis.p2c(yaxis.max-val),
              w = Math.abs(x-l);
          
          ctx.save();
          ctx.translate(x, yaxis_zero-h);

          var inside = (l >= 0 && r < plot.width());
          drawEllipse(ctx, -w, 0, w*2, h*2, inside);

          if (inside) {
            ctx.strokeStyle = strokeCol;
            if (opacity != 0) ctx.fill();
            if (strokeCol != null) ctx.stroke();
          } else {
            ctx.strokeStyle = 'grey';
            ctx.stroke();
          }
          
          ctx.restore();
        }

        ctx.beginPath();
        ctx.moveTo(0, yaxis_zero);
        ctx.lineTo(plot.width(), yaxis_zero);
        ctx.closePath();
        ctx.stroke();
        
        ctx.restore();
      }
    });
  }
  
  $.plot.plugins.push({
    init: init,
    options: options,
    name: "curvy",
    version: "0.1"
  });
})(jQuery);