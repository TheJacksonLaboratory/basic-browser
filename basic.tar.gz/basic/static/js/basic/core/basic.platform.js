/**
 * Core file for BASIC platform.
 * Requires pub/sub mechanism (default is using jQuery pub/sub plugin by Peter Higgins).
 */

var BASIC = (function() {
    var _modules = {},       // { mod_id -> module (dictionary) }
        _deps_list = {},     // { mod_id -> [dependent modules] }
        _deps_count = {},    // { mod_id -> unsatisfied_count (zero means all clear) }
        _initialized = {}    // { mod_id -> True (if not inside, means not initialized yet) }
        ;

    function _refresh_dep(mod_id) {
        for (var i in _deps_list[mod_id]) {
            var dep_mod = _deps_list[mod_id][i];
            _deps_count[dep_mod]--;
        }
    };

    return {
        /**
         * Called by components/plugins
         */
        register: function(mod_id, module) {
            _modules[mod_id] = module;
            
            // module is a dictionary; iterate each item in module
            for (var i in module) {
                var item = module[i];
                if (_.isFunction(item)) {
                    _.bind(item, module);
                    if (i[0] !== '_') {
                        // methods that start with underscore are private
                        // if a pub is broadcast, we invoke the corresponding function in the module
                        $.subscribe(mod_id + '.' + i, function() {
                            var moo = mod_id;
                            if (! _initialized[moo]) {
                                // console.warn('Service in module [' + moo + '] invoked but it is not (yet) loaded.');
                            }
                        });
                        $.subscribe(mod_id + '.' + i, item);
                    } else if (i === '__deps__') {
                        var deps = item();
                        for (var j in deps) {
                            var d = deps[j];
                            if (_deps_list[d] == null) _deps_list[d] = [];
                            _deps_list[d].push(mod_id);
                        }
                        if (_deps_count[mod_id] == null) _deps_count[mod_id] = 0;
                        _deps_count[mod_id] += deps.length;
                    }
                }
            }
            
            $.publish('basic.platform.__reg__', [mod_id]);
        },
        
        /**
         * Called after document is ready
         */
        initialize: function(args) {
            var queues = [];
            for (var mod_id in _modules) {
                queues.push({ id: mod_id, module: _modules[mod_id] });
            }
            
            function _init_helper(inited_mod) {
                _initialized[inited_mod] = true;
                while (queues.length > 0) {
                    var q = queues.shift(),
                        mod_id = q.id,
                        module = q.module;
                    
                    if (_deps_count[mod_id] > 0) {
                        // defer initialization
                        queues.push(q);
                        continue;
                    }
                    
                    (function() {
                        var _mod_id = mod_id;
                        if (BASIC_DEBUG) console.log('Module [' + mod_id + '] init');
                        if (module.__init__ != null) {
                            // pass arguments from caller to each component
                            var def = module.__init__($.extend(args, {
                                // also pass some platform-specific variables, if any
                            }));
                            
                            var done_callback = function() { 
                                // callback function to be called by component after __init__ is done
                                _refresh_dep(_mod_id);
                                BASIC_log.info('Module [' + mod_id + '] loaded');
                                if (BASIC_DEBUG) BASIC_log.debug('Module [' + mod_id + '] loaded');
                                $.publish('basic.platform.__init__', [_mod_id]);
                            };
                            
                            if (_.isUndefined(def)) {
                                // if nothing is returned, we assume it's a sync operation
                                done_callback();
                            } else {
                                def.done(done_callback);
                            }
                        }
                    })();
                    break;
                }
                if (_modules.length === _initialized.length) {
                	$.publish('basic.platform.__done__');
                } 
            }
            
            $.subscribe('basic.platform.__init__', _init_helper);
            _init_helper();
        }
    };
})();