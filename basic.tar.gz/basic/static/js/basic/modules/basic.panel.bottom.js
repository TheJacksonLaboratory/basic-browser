/**
 * Provides API to perform operations on bottom panels
 */
BASIC.register('gis.basic.panel.bottom', (function() {
  var global = null;
  return {
    __init__: function(args) {
      global = args.global;
      
      var self = this;
      global.tab_holder.css({
        height: global.bottom_panel.height()-6
      }).tabby({
        close: function(ev, ui) {
          if (ui.count <= 1) self.hide();
        }
      });
    },
    
    __deps__: function() {
      return ['gis.basic.layout'];
    },
    
    addTab: function(title, content, permanent, tab_id, callback) {
      var div = global.tab_holder.tabby('addTab', title, content, permanent, tab_id);
      if (callback != null) callback(div);
    },
    
    toggle: function() {
        if (global.no_panel_op) return;
        var ev = global.bottom_panel.css('bottom')[0] === '-' 
                   ? BASICEvent.PANEL_BOTTOM_SHOW
                   : BASICEvent.PANEL_BOTTOM_HIDE;
        $.publish(ev);
    },
    
    show: function() {
      if (global.bottom_panel.css('bottom')[0] === '-') { // has minus
        global.bottom_panel.animate({ bottom: '+=' + (global.bottom_panel.height()-6) }, { // -6 is the height of separator
          step: global.fun_bottom,
          complete: function() {
            global.bottom_panel.resizable('enable');
            global.bottom_sep.removeClass('collapsed');
            BASIC_local(BASICStorage.PANEL_BOTTOM_HIDDEN, false);
            global.basic_navbar.find('.menu-panel-bottom').removeClass('panel-hide').addClass('panel-show');
          }
        });
      }
    },
    
    hide: function(animDur) {
      if (global.bottom_panel.css('bottom')[0] !== '-') {
        global.bottom_panel.animate({ bottom: '-=' + (global.bottom_panel.height()-6) }, { // -6 is the height of separator
          step: global.fun_bottom,
          duration: animDur || 400,
          complete: function() {
            global.bottom_panel.resizable('disable');
            global.bottom_sep.addClass('collapsed').show();
            BASIC_local(BASICStorage.PANEL_BOTTOM_HIDDEN, true);
            global.basic_navbar.find('.menu-panel-bottom').removeClass('panel-show').addClass('panel-hide');
          }
        });
      }
    }

  };
})());

(function ($) {
	var tab_count = 1;
	
    $.widget("gis.tabby", {
        options: {
	        // local vars
	        _vars: {
	        	ul: null,      // holder for tab headers
	        	content: null, // holder for tab panes
	        	anchors: {}       // altId -> anchor (tab header)
	        }
        },
        
	    addTab: function(title, content, immortal, altId) {
            /*
             * Specify altId if you don't want to have more than one tab with the same altId
             */
            
            var self = this,
            	el = this.element,
            	tabId = el.attr('id') + '-tabs-' + tab_count,
                sharpId = '#' + tabId;
            
            // check first if we already have tab with the same altId
            if (altId && this.options._vars.anchors[altId]) {
            	var anchor = this.options._vars.anchors[altId],
            		tab = $(anchor.attr('id'));
            	
            	tab.empty().append(content);
            	this._activate_tab(anchor);
            	return tab;
            }
            
            // no existing altId
            var tab = $('<div>').attr({ id: tabId })
        						.addClass('tab-pane flexitab')
					            .append(content)
					            .appendTo(this.options._vars.content);

			tab.height(el.height() - this.options._vars.ul.height()-15);
		                
            var li = $('<li>').appendTo(this.options._vars.ul),
            	anchor = $('<a>').attr({ href: sharpId, 'data-toggle': 'tab' }).html(title).appendTo(li);
            
            // record altId for later use
            if (altId) {
	            anchor.data('alt-id', altId);
	            this.options._vars.anchors[altId] = anchor;
            }
            
            if (! immortal) { // immortal=cannot be closed
            	$('<button>').addClass('close').html('&nbsp;&times;').appendTo(anchor);
            }
            
            this.options._vars.ul.find('>li.active').removeClass('active');
            this.options._vars.content.find('>div.active').removeClass('active');
            
            li.addClass('active');
            tab.addClass('active');
                        
            tab_count++;
            return tab;
        },
        
        _activate_tab: function(anchor) {
        	$(anchor.attr('href')).addClass('active');
        	anchor.parent().addClass('active');
        },
        
        _create: function() {
            var self = this, el = $(this.element);
            
            this.options._vars.ul = $('<ul>').addClass('nav nav-tabs').appendTo(el);
            this.options._vars.content = $('<div>').addClass('tab-content').appendTo(el);
            
            el.addClass('basic-tabby').on('click', 'button.close', function(ev) {
                ev.preventDefault();
            	var anchor = $(this).parent(),
            		li = anchor.parent(),
            		content = $(anchor.attr('href'));
            	
            	if (li.hasClass('active')) {
            		// activate next tab, if not available, previous tab
	            	var next_anchor = li.next().find('> a'),
	            		prev_anchor = li.prev().find('> a');
	            	
            		self._activate_tab(next_anchor.length ? next_anchor : prev_anchor);
            	}
            	
            	var alt_id = anchor.data('alt-id');
            	if (alt_id) delete self.options._vars.anchors[alt_id];
            	
            	content.remove();
            	li.remove();
            	
            	// trigger event [close] with args { count: number of open tabs }
            	self._trigger('close', ev, { count: self.options._vars.ul.find('>li').length });
            });
        }
    });
})(jQuery);