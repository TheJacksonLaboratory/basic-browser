BASIC.register('gis.basic.logger', (function() {
  var HISTORY_LENGTH = 100;
  
  var global = null,
      log_panel = null,
      lines = [];

  function _render() {
    if (log_panel == null) return;
    log_panel.empty();
    _.each(lines, function(line) {
      var d = new Date();
      $('<div>').css({ color: line.color }).text(d.toLocaleString() + ' [' + line.type + '] ' + line.message).prependTo(log_panel);
    });
  };

  return {
    __init__: function(args) {
      global = args.global;
      
      $.publish('gis.basic.panel.bottom.addTab', ['Log', '', true, null, function(tab) {
        log_panel = tab.css({ 'font-family': 'monospace' });
      }]);
      
      global.fun_bottom(); // call this to adjust the height of tab holder
    },
    
    __deps__: function() { 
      return ['gis.basic.panel.bottom']; 
    },
    
    log: function(type, color, message) {
      lines.push({ type: type, color: color, message: message });
      if (lines.length > HISTORY_LENGTH) {
        lines = lines.slice(1);
      }
      _render();
    }
  };
})());