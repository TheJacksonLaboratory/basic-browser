BASIC.register('gis.basic.corenav', (function() {
  var global = null,
      position = null,
      chrom_sizes = null;
  
  return {
    __init__: function(args) {
      position = args.position;
      global = args.global;
      
      return $.Deferred(function(def) {
        $.publish('gis.basic.bootstrap.getChromInfo', function(info) {
          chrom_sizes = info.sizes;
          def.resolve();
        });
      }).promise();
    },
    
    __deps__: function() {
      return ['gis.basic.bootstrap'];
    },
    
    setLocationAndRefresh: function(chrom, start, end) {
      // Full package
      $.publish(BASICEvent.NAV_SET_CHROM, chrom);
      $.publish(BASICEvent.NAV_SET_LOCATION, [start, end]);
      $.publish(BASICEvent.NAV_REFRESH, "full");
    },
    
    setChromosome: function(chrom) {
      $.publish(BASICEvent.NAV_SET_CHROM_AND_SIZE, [chrom, chrom_sizes[chrom]]);
    },
    
    setChromosomeAndSize: function(chrom, size) {
      position.chrom = chrom;
    },
    
    setLocation: function(start, end) {
      position.start = start;
      position.end = end;
    },
    
    getLocation: function(callback) {
      callback($.extend({}, position));
    },
    
    refresh: function(type, param) {
      if (type == "full") {
        // notify server of new location on full refresh
        $.post(BASICService.COOKIE_SET, position);
        $.address.value('?' + $.param({ c: position.chrom, s: position.start, e: position.end }));
      }
    },
    
    zoomTo: function(chrom, start, end) {
      if (chrom == null) chrom = position.chrom;
      
      var size = chrom_sizes[chrom],
          s = Math.max(start, 1) || 1,
          e = Math.min(end, size) || size;
      
      if (!_.isUndefined(chrom)) {
        global.select_chrom.val(chrom);
      }
      
      $.publish(BASICEvent.NAV_SET_CHROM_AND_SIZE, [chrom, size]);
      $.publish(BASICEvent.NAV_SET_LOCATION, [Math.round(s), Math.round(e)]);
      $.publish(BASICEvent.NAV_REFRESH, 'full');    
    },

    zoomIn: function() {
      var s = position.start,
          e = position.end,
          m = (s+e)/2,
          x = (e-s+1)/4;
      $.publish('gis.basic.corenav.zoomTo', [position.chrom, Math.round(m-x), Math.round(m+x)-1]);
    },

    zoomOut: function() {
      var s = position.start,
          e = position.end,
          m = (s+e)/2,
          x = Math.max(1, e-s);
      $.publish('gis.basic.corenav.zoomTo', [position.chrom, Math.round(m-x), Math.round(m+x)+1]);
    }
  };
  
})());
