BASIC.register('gis.basic.events', (function() {
    var global = null;
    
    function setup() {
        /* ------------------------------------- 
         *    EVENT SUBSCRIPTIONS
         * ------------------------------------- */
            
        // resize the panels when window size changes
        // also tell all the tracks to redraw themselves accordingly
        var w_dim = { width: $(window).width(), 
                      height: $(window).height() };
        
        var lazy_pub_winresize = _.debounce(function() { $.publish(BASICEvent.WIN_RESIZE); }, 1000);
        
        $(window).resize(function() {
            // currently this event is triggered even when only track is resized
            // so we need to make sure this is triggered only when window dimension changes
            var win_w = $(window).width(),
                win_h = $(window).height();

            if (w_dim.width === win_w && w_dim.height === win_h) return;
            w_dim = { width: win_w, height: win_h };
            
            global.world.css({
                height: win_h-global.basic_navbar.height()
            });
            
            var w = global.left_panel.offset().left + global.left_panel.width() + global.left_sep.width();
            global.middle_panel.css({ left: w, width: win_w-w });
            global.center_panel.css({
                height: global.middle_panel.height() - global.control_panel.height()
            });

            global.left_panel.css({ height: '100%' });
            lazy_pub_winresize();
        });

        $.subscribe(BASICEvent.WIN_RESIZE, function() {
            //global.left_panel_accord.css({ height: global.world.height() }).accordion('resize');
            global.left_sep.css({ height: global.world.height() });
            global.awsum_bar.awesome('hresize');
            global.full_chrom_view.chromview('hresize');
            global.part_chrom_view.chromview('hresize');
            global.acgt_view.acgtview('hresize');
            $.publish(BASICEvent.TRACK_HRESIZE);
        });

        $.subscribe(BASICEvent.NAV_SET_CHROM_AND_SIZE, function (chrom, size) {
            global.awsum_bar.awesome('setLocation', { chrom: chrom });
            global.full_chrom_view.chromview('setChrom', chrom);
            global.part_chrom_view.chromview('setChrom', chrom);
            global.full_chrom_view.chromview('setLimits', 1, size);
            global.acgt_view.acgtview('setLocation', { chrom: chrom });
        });

        $.subscribe(BASICEvent.NAV_SET_LOCATION, function (start, end, source) {
            global.awsum_bar.awesome('setLocation', { start: start, end: end });
            global.full_chrom_view.chromview('setValues', start, end);
            global.part_chrom_view.chromview('setLimits', start, end);
            global.acgt_view.acgtview('setLocation', { start: start, end: end });
        });

        $.subscribe(BASICEvent.TRACK_CHANGE, function () {
            $.publish('gis.basic.tracklist.getActiveTrackIDs', function(data) {
                BASIC_local(BASICStorage.TRACK_ACTIVE_PREFIX + global.asm, { list: data });
            });
        });

        /*
         * URL ADDRESS (WITH HASHTAG)
         */ 

        var insect = _.intersection(['c', 's', 'e'], $.address.parameterNames());
        if (insect.length === 3) {
            $.publish(BASICEvent.NAV_ZOOM_TO, [$.address.parameter('c'), $.address.parameter('s'), $.address.parameter('e')]);
        } else if (insect.length === 1 && insect[0] == 'c') {
            $.publish(BASICEvent.NAV_SET_CHROM, [$.address.parameter('c')]);
        }
        
        $.address.externalChange(function(ev) {
            var par = ev.parameters;
            $.publish(BASICEvent.NAV_ZOOM_TO, [par.c, parseInt(par.s), parseInt(par.e)]);
        });
        
        /*
         * SHOW/HIDE LEFT/BOTTOM PANELS
         */  
        
        global.basic_navbar.find('.menu-panel-left > a').click(function(ev) {
            ev.preventDefault();
            $.publish(BASICEvent.PANEL_LEFT_TOGGLE);
        });
        global.basic_navbar.find('.menu-panel-bottom > a').click(function(ev) {
            ev.preventDefault();
            $.publish(BASICEvent.PANEL_BOTTOM_TOGGLE);
        });
        
        /*
         * SPECIAL EVENTS
         */ 
    
        // Currently only used by PGS report page
        $.subscribe(BASICEvent.GOTO_GENE, function(genesym) {
            global.awsum_bar.awesome("setLocation", genesym);
        });
    }
    
    return {
        __init__: function(args, done) {
            global = args.global;
            
            setup();
            
            return $.Deferred(function(def) {
                $.publish('gis.basic.corenav.getLocation', function(loc) {
                    $.publish(BASICEvent.NAV_SET_CHROM, loc.chrom);
                    $.publish(BASICEvent.NAV_SET_LOCATION, [loc.start, loc.end]);
                    def.resolve();
                });
            }).promise();
        },
        
        __deps__: function() {
                return ['gis.basic.comsetup', 'gis.basic.corenav'];
        }
    };
})());