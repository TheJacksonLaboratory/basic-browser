BASIC.register('gis.basic.trackmanager', (function() {
    var app_url = null,
        global = null,
        _tracklist = null,
        _tracks = {};
    
    // increased when quick refresh is started, decreased when it's done
    var _quickRefreshSemaphore = 0;
    
    // increased when full refresh is started, decreased when it's done
    var _fullRefreshSemaphore = 0; 

    function _subscribeTrack(c, cn, tr, hs) {
        /*
         * c  = widget component
         * cn = component name
         * tr = track
         * hs = history? to keep track of all subscriptions of this track
         */
        hs.push($.subscribe(BASICEvent.TRACK_CLOSE, function (track_id, source) {
            if (track_id != tr.track_id) return;

            // if source is not from the track widget itself, 
            // we need to invoke 'close()' on the widget manually
            if (source != 'track') c[cn]('close');

            // unsubscribe from all channels
            for (var i in hs) $.unsubscribe(hs[i]);
        }));
        
        hs.push($.subscribe(BASICEvent.NAV_REFRESH, function (type, param) {
            if (type == 'full') {
                _fullRefreshSemaphore++;
                c[cn]('fullRefresh', true); // forced refresh
                _fullRefreshSemaphore--;
            } else if (type == 'fast') {
                if (param != tr.track_id) return; // only do quick refresh on the sliding track
                if (_quickRefreshSemaphore > 0) return; // don't do quick refresh if it's still in progress
                _quickRefreshSemaphore++;
                // param => track_id 
                c[cn]('quickRefresh', true); // forced refresh
                _quickRefreshSemaphore--;
            }
        }));
        
        hs.push($.subscribe(BASICEvent.NAV_SET_LOCATION, function (start, end) {
            c[cn]('setLocation', start, end);
        }));
        hs.push($.subscribe(BASICEvent.NAV_SET_CHROM_AND_SIZE, function (chrom, size) {
            c[cn]('setChromosome', chrom, size);
        }));
        hs.push($.subscribe(BASICEvent.TRACK_HRESIZE, function() { c[cn]('hresize'); }));
        hs.push($.subscribe(BASICEvent.TRACK_VRESIZE, function() { c[cn]('vresize'); }));
        hs.push($.subscribe(BASICEvent.TRACK_ALLOW_SLIDE, function(b) { c[cn](b ? 'enableSlide' : 'disableSlide'); }));
    };

    function _addTrackHelper(holder, track) {
        var com = $('<li>').attr({
                'basic-track-id': track.track_id
            }).css({
                // use the width of the first component in holder (usually awesomebar)
                width: $(holder).find('>li:first').width()
            }).appendTo(holder);

        var commonHandlers = {
            table: function (ev, ui) {
                $.publish(BASICEvent.TABLE_VIEW, track);
                $.publish(BASICEvent.PANEL_BOTTOM_SHOW);
            },
            config: function (ev, ui) {
                $.publish(BASICEvent.TRACK_CONFIG, track);
                $.publish(BASICEvent.PANEL_BOTTOM_SHOW);
            },
            close: function (ev, ui) {
                $.publish(BASICEvent.TRACK_CLOSE, [track.track_id, 'track']);
            },
            closed: function (ev, ui) {
                $.publish(BASICEvent.TRACK_CHANGE);
            },
            slide: function (ev, ui) {
                $.publish(BASICEvent.NAV_SET_LOCATION, [ui.start, ui.end]);
                $.publish(BASICEvent.NAV_REFRESH, ['fast', track.track_id]);
                $.schedule(BASICEvent.TRACK_SLIDE, BASIConst.TRACK_AUTO_REFRESH_INTERVAL, function() {
                    $.publish(BASICEvent.NAV_REFRESH, 'full');
                });
            },
            stop: function (ev, ui) {
                $.publish(BASICEvent.NAV_SET_LOCATION, [ui.start, ui.end]);
                $.schedule(BASICEvent.TRACK_SLIDE, 0, function() {
                    // cancel the schedule by 'slide' event and do refresh right away
                    $.publish(BASICEvent.NAV_REFRESH, 'full');
                });
            }
        };

        // Get current location, then create the track
        $.publish('gis.basic.corenav.getLocation', function(_loc) {
            
            var commonParams = {
                    tid: track.track_id,
                    track_id: track.track_id,
                    title: track.name,
                    url: app_url + '/basic/browser/track/' + track.type + '/',
                    location: {
                        chrom: _loc.chrom,
                        start: _loc.start,
                        end: _loc.end
                    },
                    source: (track.configs || {}).source,
                    // applicable to track with multi-series support; to be passed as srckey in request to URL
                    options: (track.configs || {}).options // global settings
                };

            var comName = track.type + 'track'; // name of GIS widget component to use
            
            track._comName = comName;
            track._component = com;
            
            if (track.type == 'gene') { // gene
                com[comName]($.extend({ // include common handlers in parameters
                    asm: _loc.asm,
                    limit: BASIConst.LIMITS[track.type] || BASIConst.LIMITS['default'],
                    click: function (ev, ui) {
                        // open the area spanned by the clicked gene
                        $.publish(BASICEvent.NAV_ZOOM_TO, [null, ui.item.start, ui.item.end]);
                    }
                }, commonParams, commonHandlers, {
                    url: app_url + '/basic/sources/genes/query/'
                }));
            } else if (track.type == 'scls') { // single clusters
                com[comName]($.extend({ 
                    limit: BASIConst.LIMITS[track.type] || BASIConst.LIMITS['default'], 
                    click: function (ev, ui) {
                        $.publish(BASICEvent.NAV_ZOOM_TO, [null, ui.item.start, ui.item.end]);
                    }
                }, commonParams, commonHandlers));
            } else if (track.type == 'pcls') { // paired clusters
                com[comName]($.extend({
                    limit: BASIConst.LIMITS[track.type] || BASIConst.LIMITS['default'],
                    click: function (ev, ui) {
                        if (ui.which === 'head') {
                            // go to tail
                            $.publish(BASICEvent.NAV_ZOOM_TO, [ui.item.chrom2, ui.item.start2, ui.item.end2]);
                        } else if (ui.which == 'tail') {
                            // go to head
                            $.publish(BASICEvent.NAV_ZOOM_TO, [ui.item.chrom, ui.item.start, ui.item.end]);
                        } else {
                            // open full span
                            $.publish(BASICEvent.NAV_ZOOM_TO, [null, 
                                                               Math.min(ui.item.start, ui.item.start2), 
                                                               Math.max(ui.item.end, ui.item.end2)]);
                        }
                    }
                }, commonParams, commonHandlers));
            } else if (track.type == 'trfac' // transaction factors 
                ) {
                com[comName]($.extend({ 
                    limit: BASIConst.LIMITS[track.type] || BASIConst.LIMITS['default'] 
                }, commonParams, commonHandlers));
            } else if (track.type == 'ltag') { // 'lettered' tags 
                com[comName]($.extend({ 
                    limit: BASIConst.LIMITS[track.type] || BASIConst.LIMITS['default'],
                    asm: _loc.asm,
                    acgt_url: BASICService.CHROME_ACGT
                }, commonParams, commonHandlers));
            } else if (track.type == 'curv') { // curvaceous track to display ChIA-PET's interactions
                com[comName]($.extend({
                    series: (track.configs || {}).series
                }, commonParams, commonHandlers));
            } else if (track.type == 'cov' // max
                    || track.type == 'avg' // average
                    || track.type == 'cif' // countif
            ) { 
                com[comName]($.extend({
                    series: (track.configs || {}).series // series-specific configs, e.g. color, orientation, fill
                }, commonParams, commonHandlers, {
                    url: app_url + '/basic/sources/coverage/' + track.type + '/'
                }));
            } else if (track.type == 'snp') { // 
                com[comName]($.extend({ 
                    asm: _loc.asm,
                    limit: BASIConst.LIMITS[track.type] || BASIConst.LIMITS['default'] 
                }, commonParams, commonHandlers, {
                    url: app_url + '/basic/sources/snp/query/'
                }));
            }
    
            (function () {
                // subscribe track to topics -- must be in closure to retain 
                // local variables related to the track
                _subscribeTrack(com, comName, track, []);
            })();
            com[comName]('fullRefresh', true); // first drawing
            // must do this for the new track's location to be updated
            
            $.publish(BASICEvent.NAV_SET_CHROM, _loc.chrom);
            $.publish(BASICEvent.NAV_SET_LOCATION, [_loc.start, _loc.end]);
            $.publish(BASICEvent.TRACK_OPEN, track.track_id);
            $.publish(BASICEvent.TRACK_CHANGE);
        });
    }
    
    return {
        __init__: function(args) {
            app_url = args.APP_URL;
            global = args.global;
            
            return $.Deferred(function(def) {
                $.getJSON(BASICService.TRACK_LIST, { asm: global.asm }, function(data) {
                    _tracklist = data;
                    
                    for (var k in data) {
                        var v = data[k];
                        _tracks[v.track_id] = v;
                    }
                    
                    def.resolve();
                });
            }).promise();
        },
        
        __deps__: function() {
            return ['gis.basic.comsetup'];
        },
        
        getTrackList: function(callback) { // called by basic.tracklist.js
            callback(_tracklist);
        },
        
        add: function (track_id, callback) {
            var track = _tracks[track_id];
            $.getJSON(BASICService.TRACK_CONFIG_GET, { track_id: track_id }, function(data) {
                data = BASIC_recurseval(data);
                track.configs = $.extend(true, data['public'], data['private']);
                _addTrackHelper(global.track_holder, track);
                if (callback) callback();
            });
        },
        
        remove: function (track_id) {
            $.publish(BASICEvent.TRACK_CLOSE, track_id);
        },
        
        reload: function (track_id) {
            var track = _tracks[track_id];
            $.getJSON(BASICService.TRACK_CONFIG_GET, { track_id: track_id }, function(data) {
                data = BASIC_recurseval(data);
                track.configs = $.extend(true, data['public'], data['private']);
                track._component[track._comName]('setOptionsConfig', (track.configs || {}).options);
                track._component[track._comName]('setSeriesConfig', (track.configs || {}).series);
                track._component[track._comName]('fullRefresh', true);
            });
        }
    };
})());