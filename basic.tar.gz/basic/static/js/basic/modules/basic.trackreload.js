BASIC.register('gis.basic.trackreload', (function() {
    var global = null,
        track_list = null;
    
    function setup() {
        // open tracks from the last session for this assembly
        var active_tracks = (BASIC_local(BASICStorage.TRACK_ACTIVE_PREFIX + global.asm) || {}).list;
        
        return $.Deferred(function(def) {
            if (active_tracks != null && active_tracks.length > 0) {
        	    $.publish('gis.basic.tracklist.getTracks', function(track_list) {
                    var barrier = 0,
                        valid_tracks = [];
                        
                    _.each(active_tracks, function(trk_id) {
                        if (track_list[trk_id] != null && track_list[trk_id] !== 'null') {
                            valid_tracks.push(trk_id);
                            barrier++;
                        }
                    });
    
                    if (barrier > 0) {
                        _.each(valid_tracks, function(trk_id) {
                            $.publish(BASICEvent.TRACK_MGR_ADD, [trk_id, function() {
                                barrier--;
                                if (barrier <= 0) def.resolve();
                            }]);
                        });
                    } else {
                        // no valid tracks
                        def.resolve();
                    }    
                });
            } else {
                // no recorded tracks
                def.resolve();
            }
        }).promise();
    }
    
    return {
        __init__: function(args) {
            global = args.global;
            
            return $.Deferred(function(def) {
                setup().done(function() {
                    // refresh the tracks to expand list with active tracks
                    $.publish('gis.basic.tracklist.refresh');
                    
                    // wait 1 second just to be sure
                    _.delay(function() { 
                        // the following must be done only after all tracks have been opened
                        if (BASIC_local(BASICStorage.PANEL_LEFT_HIDDEN)) {
                            $.publish(BASICEvent.PANEL_LEFT_HIDE);
                        }
                        $.publish(BASICEvent.PANEL_BOTTOM_HIDE);
                    }, 1000);
                    def.resolve();
                });
            }).promise();
        },
        
        __deps__: function() {
            return ['gis.basic.tracklist', 'gis.basic.trackmanager', 'gis.basic.events'];
        }
    };
})());