BASIC.register('gis.basic.tableview', function() {

    return {
        __init__: function(args) {
        },
        
        __deps__: function() {
            return ['gis.basic.panel.bottom'];
        },
        
        viewTable: function(track) {
            $.publish('gis.basic.panel.bottom.addTab', 
                      [track.name, '', false, 'tbview_' + track.track_id, function(tab) {
                tab.tablexplorer({
                    url: BASICService.TABLE_EXPLORE,
                    table_id: track.table_id,
                    limit: 100,
                    scrollTarget: tab.parent(),
                    click: function (ev, ui) {
                        var minspan = 100, // viewing span must be at least 100bp
                            span = ui.end-ui.start+1;
                        if (span < minspan) {
                            var m = ui.start+span/2;
                            ui.start = Math.round(m-minspan/2);
                            ui.end = Math.round(m+minspan/2-1);
                        }
                        $.publish(BASICEvent.NAV_ZOOM_TO, [ui.chrom, ui.start, ui.end]);
                    },
                    download: function(ev, ui) {
                        document.location = BASICService.TABLE_DOWNLOAD + '?' + $.param(ui);
                    }
                });
            }]);
        }
    };
}());
