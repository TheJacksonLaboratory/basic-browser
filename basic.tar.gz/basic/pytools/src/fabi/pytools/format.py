'''
Formatting-related functions (presentation).

Created on Jun 8, 2011

@author: mulawadifh
'''
import re

'''
Converts time in seconds to a more readable format.
'''
def humantime(t):
  s = ''
  x = int(t/86400)
  if x > 0: 
    s += '%.2fd ' %(x)
    t %= 86400

  x = int(t/3600)
  if x > 0: 
    s += '%.2fh ' %(x)
    t %= 3600

  x = int(t/60)
  if x > 0: 
    s += '%.2fm ' %(x)
    t %= 60

  x = t
  s += '%.2fs' %(x)
  return s

def intcomma(val):
  if val < 1000: return str(val)
  val = str(val)
  regex = re.compile(r"(-?[0-9]+)([0-9]{3})")
  while regex.search(val):
    val = regex.sub(r"\1,\2", val)
  return val

def shorten(text, limit):
  if not text: return text
  if len(text) <= limit: return text
  p = text.rfind(" ", 0, limit)
  return text[:p] if p>limit-3 else '%s...'%text[:limit-3]

