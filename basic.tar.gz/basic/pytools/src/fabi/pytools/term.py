'''
Created on Jun 17, 2011

@author: mulawadifh
'''
from fabi.pytools.format import shorten
from termcolor import colored
import os
import re
import subprocess
import sys
import tempfile

class Tabulator(object):
  '''
  To display formatted table content on terminal
  '''
  def __init__(self, colors=None):
    '''
    DEFAULT
    -------
    colors: {
      header: 'white',
      sep: 'white'
    }
    '''
    self.columns = list()
    self.colors = colors or dict()
  
  def add_column(self, name, width, color=None, just='left'):
    '''just: text justification {left,right}
    '''
    self.columns.append(dict(name=name, width=width, color=color, just=just))
    
  def print_table(self, source, callback=None):
    '''source is a list of tuple or generator that returns a tuple in the same order
       as the columns added'''

    header = list()
    separator = list()
    for col in self.columns:
      w = col['width']
      if col['just'] == 'left':
        text = str(col['name']).ljust(w, ' ')
      elif col['just'] == 'right':
        text = str(col['name']).rjust(w, ' ')
      else:
        raise Exception("Illegal argument: just='%s'"% col['just'])
      header.append(text[:w])
      separator.append('-' * w)

    print colored('\t'.join(header), self.colors.get('header', 'white'))
    print colored('\t'.join(separator), self.colors.get('sep', 'grey'))
    
    for entry in source:
      row = list()
      for col, val in zip(self.columns, entry):
        w = col['width']
        text = shorten(str(val), w)
        if col['just'] == 'left':
          text = text.ljust(w, ' ')
        elif col['just'] == 'right':
          text = text.rjust(w, ' ')
        if col['color']:
          text = colored(text, col['color'])
        row.append(text)
      
      print '\t'.join(row)
      if callback: callback(entry)

    print colored('\t'.join(separator), self.colors.get('sep', 'grey'))

def stdin_or_editor(message=None, preloaded=None, editor=None, commentsign='#'):
  '''Reads from stdin. If stdin is not specified, runs an editor
     If there's no change, the returned value is None, otherwise
     it's a string (which could be empty)'''
  
  content = None
  if not sys.stdin.isatty(): # something's streamed to stdin
    return sys.stdin.read()
  
  ed = editor or os.environ.get('EDITOR') or _get_editor()
  if not ed: raise Exception("No editor found. Please specify a default one in environment variable [EDITOR]")

  # create temp file; put existing meta value inside, if present
  tmp = tempfile.NamedTemporaryFile(suffix=".edit", delete=False)
  tmpname = tmp.name
  if preloaded: tmp.write(preloaded)
  tmp.write('\n\n')
  
  if message:
    if type(message) != list: 
      message = [message]
    for m in message:
      tmp.write('%s %s\n'% (commentsign, re.sub(r'[\n\r]+', r'\n', m)))
  
  tmp.write('%s %s'% (commentsign, "Lines that start with '%s' will be ignored."% commentsign))
  tmp.close()
  
  # invoke editor
  bef = os.stat(tmpname).st_mtime
  subprocess.call([ed, tmp.name])
  aft = os.stat(tmpname).st_mtime
  modified = bef != aft
  
  if modified:
    with open(tmpname) as tmp:
      content = ''.join(line for line in tmp if not line.startswith(commentsign)).rstrip()

  os.remove(tmpname)
  return content

def _get_editor():
  for e in ['nano', 'vim', 'vi', 'emacs',]:
    for p in os.environ.get('PATH','').split(os.pathsep):
      ed = os.path.join(p,e)
      if os.path.exists(ed): 
        break
      else:
        ed = None
    if ed: break
  return ed

if __name__ == '__main__':
  with open(sys.argv[2]) as f:
    print stdin_or_editor(sys.argv[1], f.read())
