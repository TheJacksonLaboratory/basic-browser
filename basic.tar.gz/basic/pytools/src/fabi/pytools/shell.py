'''
Wrapper to shell commands.
'''
from fabi.pytools.io import ouvrir, deleting
from fabi.pytools.run import together
import os
import re
import subprocess as sp
import tempfile
from contextlib import contextmanager

class Shell(object):
    class ShellException(Exception):
        def __init__(self, cmd, stdin, stdout, stderr):
            super(Shell.ShellException, self).__init__()
            self.command = re.sub(r'([\|><])\s*', r'\\\n\1 ', cmd.strip())
            self.stdin = stdin
            self.stdout = stdout
            self.stderr = stderr
        def __repr__(self):
            out, sep = [], '-'*80
            for attr in ('command', 'stdin', 'stdout', 'stderr'):
                val = getattr(self, attr)
                if val: out += ['\n', sep, ' %s'% attr.upper(), sep, val]
            return '\n'.join(out)
        def __str__(self):
            return self.__repr__()
    
    def __init__(self, cmd=None, **kwargs):
        # allow shortcut like: Shell('ls') instead of Shell()('ls')
        # we cannot return the stdout/stderr though
        if cmd: self.__call__(cmd, **kwargs)
    
    def __call__(self, cmd, input=None, output=sp.PIPE, error=sp.PIPE):
        '''input = either string, stream, or nothing'''
        
        cmd = re.sub('\s{2,}', ' ', cmd)
        if isinstance(input, basestring):
            stdin = sp.PIPE
        elif isinstance(input, file):
            stdin = input
            input = None
        else:
            stdin = None
        
        proc = sp.Popen(cmd, shell=True, stdin=stdin, stdout=output, stderr=error) 
        out, err = proc.communicate(input)
        
        if proc.returncode != 0:
            raise Shell.ShellException(cmd, input, out, err)
        
        return out, err # only returned on success

class ShellChain(object):
    '''
    Used to run multiple commands chained together with pipe
    Example:
    
    ch = ShellChain()
    ch.chain('ls')
      .chain('grep Hello')
      .chain('sed -e "s/ /\n/g"')
      .execute()
        
    The above command is equal to:
    $ ls | grep Hello | sed -e "s/ /\n/g"
    '''
    def __init__(self, shell=None):
        self._shell = shell or Shell()
        self.reset()
    
    def reset(self):
        self._cmds = []
        self._context = {}
        return self
    
    def chain(self, cmd, use_context=True):
        # queues a new command at the end of the list
        if use_context:
            self._cmds.append(cmd.format(**self._context))
        else:
            self._cmds.append(cmd)
        return self

    def context(self, ctx): 
        # will be used as parameter to string.format()
        # must be set before calling chain()
        self._context = ctx
        return self

    def execute(self, input=None, output=sp.PIPE):
        try:
            out, _ = self._shell('|'.join(self._cmds), input, output)
            return out
        finally:
            self.reset()

def runscript(scriptname, *args, **kwargs):
    '''Convenience shortcut to run script'''
    cmd = '%s %s %s'% (scriptname, 
                       ' '.join('"%s"'%_ for _ in args), 
                       ' '.join('--%s="%s"'%(p,q) if q is not None else '--%s'%p 
                                for p,q in kwargs.iteritems() if not p.startswith('_')))
    
    stdin = kwargs.get('_stdin')
    if stdin: cmd += '< "%s"'% stdin

    stdout = kwargs.get('_stdout')
    if stdout: cmd += '> "%s"'% stdout

    shell = kwargs.get('_shell', Shell())
    return shell(cmd)

def split_file(filename, nfile, nline=1, tmpdir=None, nproc=2):
    '''
    nfile = number of splits
    nline = split every [nline] lines
    '''
    temps = list()
    for i in xrange(nfile):
        temps.append(tempfile.NamedTemporaryFile(dir=tmpdir, delete=False, 
                                                 prefix='%s.part%04d.' %(os.path.basename(filename), i+1))) 
    
    sh = Shell()
    with ouvrir(filename) as f:
        fname = f.name
        nlines = count_line_num(fname)
        n = nlines/nfile
        if nlines % nfile>0: n += 1
        n += (nline-(n % nline)) # must be multiplies of nline
         
        with together(nproc) as tog:
            for j in xrange(nfile):
                start = j*n+1
                out = temps[j].name
                tog(sh, "tail -n +{start} < {fname} | head -{n} > {out}".format(**locals()))
            
    return [t.name for t in temps]

def is_sorted(filename, params):
    '''Checks whether a file is sorted using "sort -c"
    params are extra arguments to pass to UNIX sort, e.g. "-k3n,3 -k4,5"
    '''
    try:
        Shell()("sort -c '{params}' < '{filename}'".format(**locals()))
        return True
    except:
        return False

def get_dir_size(dir, humanize=False):
    '''Returns the size of given directory (and its subdirs)
    '''
    hum = '-h' if humanize else ''
    try:
        out, _ = Shell()("du -c {hum} '{dir}'".format(**locals()))
        val = out.rstrip().split('\n')[-1].split('\t')[0]
        return val if humanize else int(val)
    except:
        return None

@contextmanager
def split_by_col(input_, colnum, outdir='/tmp', sep='.', delete=True):
    tmpdir = tempfile.mkdtemp(dir=outdir, suffix='.split')

    closing = False # close when done
    if not isinstance(input_, file):
        input_ = open(input_)
        closing = True
    
    if isinstance(colnum, list):
        cols = ('"%s"'% sep).join('$%s'%cat for cat in colnum)
    else:
        cols = '$%s'% colnum 
    
    cmd = """awk '{ print > "%s/"%s }'"""% (tmpdir, cols)
    p = sp.Popen(cmd, shell=True, stdin=input_)
    p.wait()

    if closing: input_.close()
        
    files = os.listdir(tmpdir)
    result = dict(zip(files, [os.path.join(tmpdir, f) for f in files]))
    
    with deleting(*result.values(), delete=delete):
        yield result

def count_line_num(filename):
    return int(Shell()(r"wc -l < '%s'" %(filename))[0])