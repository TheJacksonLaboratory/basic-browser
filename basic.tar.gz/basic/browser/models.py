from django.contrib.auth.models import User, Group
from django.db import models
from fabi.pytools.format import shorten

def _shorten(text): return shorten(text, 50)

class Organism(models.Model):
    def __unicode__(self):
        return "%s (%s)" %(self.name, _shorten(self.descn))
    
    name = models.CharField(max_length=50, null=True) # popular name
    latin = models.CharField(max_length=50) # latin name
    descn = models.TextField(max_length=250, null=True, blank=True)

class TargetFactor(models.Model):
    def __unicode__(self):
        return "%s (%s)" %(self.name, self.code)
    
    name = models.CharField(max_length=50) # long name
    code = models.CharField(max_length=20, unique=True)
    descn = models.TextField(max_length=250, null=True)

class CellLine(models.Model):
    def __unicode__(self):
        return "%s (%s - %s)" %(self.name, self.org.latin, _shorten(self.descn))

    name = models.CharField(max_length=50, unique=True)
    descn = models.TextField(max_length=250, null=True, blank=True)
    org = models.ForeignKey(Organism)

class Technology(models.Model):
    def __unicode__(self):
        return "%s (%s)" %(self.name, _shorten(self.descn))
    
    name = models.CharField(max_length=50, unique=True)
    descn = models.TextField(max_length=250, null=True, blank=True)

class Project(models.Model):
    def __unicode__(self):
        return "%s (%s)" %(self.name, _shorten(self.descn))
    
    name = models.CharField(max_length=50, unique=True)
    descn = models.TextField(max_length=250, null=True, blank=True)

class Library(models.Model):
    '''This model is not a exact representation of a biological library.
    To simplify implementation, each processing of the same (biological) library
    with different parameters, extra lanes, is considered a new library by BASIC.
    '''
    def __unicode__(self):
        return "%s (%s)" %(self.name, _shorten(self.descn))

    name = models.CharField(max_length=100, unique=True)
    descn = models.TextField(max_length=500, null=True, blank=True)
    
    cell = models.ForeignKey(CellLine, null=True, blank=True)
    tech = models.ForeignKey(Technology, null=True, blank=True)
    target = models.ForeignKey(TargetFactor, null=True, blank=True)
    proj = models.ForeignKey(Project, null=True, blank=True)

    # authorized persons/groups
    owners = models.ManyToManyField(User, blank=True, null=True)
    groups = models.ManyToManyField(Group, blank=True, null=True)

class Assembly(models.Model):
    def __unicode__(self):
        return "%s (%s)" %(self.name, self.org.name)
    
    name = models.CharField(max_length=50, unique=True)
    descn = models.TextField(max_length=250, null=True, blank=True)
    org = models.ForeignKey(Organism)

class Bookmark(models.Model):
    def __unicode__(self):
        return "[%s] %s:%d-%d" %(self.name, self.chrom, self.start, self.end) 

    name = models.CharField(max_length=50) 
    asm = models.ForeignKey(Assembly)
    chrom = models.CharField(max_length=20)
    start = models.IntegerField()
    end = models.IntegerField()
    tracks = models.ManyToManyField('table.Track')
    owner = models.ForeignKey(User)
