'''
Created on Feb 26, 2012

@author: Fabianus
'''
from browser.models import Bookmark, Assembly
from table.models import Track

def initialize(engine):
    engine.register('set', handler=book_set, post=('name', 'asm', 'chrom', 'start~int', 'end~int', 't~list'))
    engine.register('get', handler=book_get, get=('asm',))
    engine.register('del', handler=book_del, post=('id',))

# -----------------------------
#  BOOKWORMS
# -----------------------------

def book_set(request, args):
    book = Bookmark(name=args['name'], 
                    asm=Assembly.objects.get(name=args['asm']), 
                    chrom=args['chrom'], 
                    start=args['start'], 
                    end=args['end'],
                    owner=request.user)
    book.save()
    
    book.tracks = Track.objects.filter(id__in=args['t'] or [])
    book.save()
    return None

def book_get(request, args): # needed by widget [bookworm]
    result = list()
    for b in Bookmark.objects.filter(asm__name=args['asm'], owner=request.user).order_by('name'):
        d = dict((_, getattr(b,_)) for _ in 'id name chrom start end'.split(' '))
        d['tracks'] = [_.id for _ in b.tracks.all()]
        result.append(d)
    return result

def book_del(request, args):
    Bookmark.objects.filter(id=args['id'], owner=request.user).delete()
    return None