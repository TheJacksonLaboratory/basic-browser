def initialize(engine):
    engine.register('passwd', handler=change_passwd, post=['curr', 'new'])

def change_passwd(request, args):
    if not request.user.check_password(args['curr']):
        return { 'status': 'ERR', 'message': 'Wrong password' }
    
    request.user.set_password(args['new'])
    request.user.save()
    return { 'status': 'OK' }