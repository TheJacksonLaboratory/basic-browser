from django.contrib import admin
from browser.models import *

class OrganismAdmin(admin.ModelAdmin):
  pass

class TargetFactorAdmin(admin.ModelAdmin):
  pass

class CellLineAdmin(admin.ModelAdmin):
  pass

class ProjectAdmin(admin.ModelAdmin):
  pass

class TechnologyAdmin(admin.ModelAdmin):
  pass

class AssemblyAdmin(admin.ModelAdmin):
  pass

def asm_name(t): return t.asm.name
asm_name.short_description = "Assembly"

class BookmarkAdmin(admin.ModelAdmin):
  list_display = ('id', 'name', 'owner',)

class LibraryAdmin(admin.ModelAdmin):
  def _owners(t): return ', '.join(sorted(u.username for u in t.owners.all()))
  def _groups(t): return ', '.join(sorted(u.name for u in t.groups.all()))
  list_display = ('id', 'name', 'proj', 'target', 'cell', 'tech', _owners, _groups)
  
admin.site.register(Organism, OrganismAdmin)
admin.site.register(TargetFactor, TargetFactorAdmin)
admin.site.register(Project, ProjectAdmin)
admin.site.register(CellLine, CellLineAdmin)
admin.site.register(Library, LibraryAdmin)
admin.site.register(Technology, TechnologyAdmin)
admin.site.register(Assembly, AssemblyAdmin)
admin.site.register(Bookmark, BookmarkAdmin)
