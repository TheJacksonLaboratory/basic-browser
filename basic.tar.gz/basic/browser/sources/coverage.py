'''
Created on Feb 27, 2012

@author: mulawadifh
'''
from browser.sources.common import utils
from django.http import HttpResponseServerError
from driver.countif import CountIf
from driver.maxi import Maxi
from driver.sigma import Sigma
from os import path
from table.models import Metadata
import settings

def initialize(engine):
    params = ('track_id', 'chrom', 'start~int', 'end~int', 'w~int', 'thres', 'srckey', 'subkey')
    engine.register('cov', handler=get_max, get=params) # backwards compat
    engine.register('max', handler=get_max, get=params)
    engine.register('avg', handler=get_avg, get=params)
    engine.register('cif', handler=get_countif, get=params)
    
_track_max_drivers = dict()
def get_max(request, args):
    def fun(drv, chrom, start, end):
        return drv.query(chrom, start, end)
    try:
        return _get_track_cov(request, args, _track_max_drivers, Maxi, fun)
    except Exception as e:
        return e

_track_avg_drivers = dict()
def get_avg(request, args):
    def fun(drv, chrom, start, end): 
        return drv.average(chrom, start, end)
    try:
        return _get_track_cov(request, args, _track_avg_drivers, Sigma, fun)
    except Exception as e:
        return e

_track_cif_drivers = dict()
def get_countif(request, args):
    def fun(drv, chrom, start, end, thres): 
        return drv.query(chrom, start, end, thres)
    try:
        return _get_track_cov(request, args, _track_cif_drivers, CountIf, fun)
    except Exception as e:
        return e

#-----------------------------------------------------------------------------
# Common method to retrieve coverage-like data structure
# drivers : cache of driver objects for different srckey
# drivcls : driver class (Maxi/Avg/Pets/CountIf)
# fun         : function which takes 1st arg = driver object, 
#                     and the rest of args = params for the driver object
#-----------------------------------------------------------------------------
def _get_track_cov(request, args, drivers, driver_cls, fun):
    srckey = args['srckey']
    if not srckey: 
        raise Exception(HttpResponseServerError('[srckey] must be given as parameter'))
    
    track_id = args['track_id']
    source = Metadata.objects.get(track__id=track_id, key='source').value
    
    cachekey = '%s.%s'% (track_id,srckey) if srckey else track_id
    
    subkey = args['subkey']
    if subkey: cachekey += '.%s'% subkey
    driver = drivers.get(cachekey)
    
    if not driver:
        # load driver
        try:
            jsobj = utils.parse_metaval(source) # it's either string, list, or dictionary
            srcfile = utils.get_srcfile(jsobj, srckey) # get value from the list/dictionary indicated by 'srckey'
            if subkey: srcfile = srcfile[subkey] # we assume the type is ALWAYS dictionary if subkey is supplied
        except Exception as e:
            raise Exception(HttpResponseServerError(e))
        
        if srcfile[0] != '/':
            srcfile = path.join(settings.TRACK_DIR, srcfile) # absolute/relative path
            
        drivers[cachekey] = driver = driver_cls(srcfile)
    
    chrom, start, end, w = args['chrom'], args['start'], args['end'], args['w']
    span = (end-start+1)
    
    nquery = min(w, span) # if genomic span is less than screen width, we do query less than "w"
    
    thres = args['thres']
    fun2 = fun
    if thres:
        thres = int(thres)
        def fun2(*args):
            return fun(args[0], args[1], args[2], args[3], thres)

    step = float(span)/w
    if nquery < w:
        result = [fun2(driver, chrom, i, i) for i in xrange(start, start+nquery)]
        return [result[int(i*step)] for i in xrange(w)]
    else:
        result = []
        l = start
        for _ in xrange(nquery):
            result.append(fun2(driver, chrom, int(l+0.5), min(int(l+step+0.5), end)))
            l += step
        return result
