from browser.models import Assembly
from browser.modsys import ModuleManager
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.sites.models import RequestSite
from django.shortcuts import render_to_response, redirect
from django.template import RequestContext
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from os import path
from util.http import cookie, get_params

import os
import re
import settings
from browser.utils import has_mod_perm

def main_default(request):
    with cookie(request) as coo:
        asm = coo.asm or 'hg19' # we assume hg19 is always present
    return redirect('{0}/basic/main/{1}'.format(settings.APP_URL, asm))

@login_required
def main(request, asm):
    with cookie(request) as coo:
        if coo.asm == asm:
            chrname, start, end = coo.chrom, coo.start, coo.end
            tracks = coo.tracks
        else:
            chrname, start, end = '', 0, 0
            tracks = ''
    return _main_helper(request, asm, chrname, start, end, tracks)

def _main_helper(request, asm, chrom, start, end, tracks=''):
    friendly = get_params(request, 'friendly')
    context = {
        'settings.APP_URL': settings.APP_URL,
        'DEBUG': 'true' if settings.DEBUG else 'false',
        'asm': asm,
        'assemblies': [_.name for _ in Assembly.objects.all().order_by('name')],
        'basic_client_modules': [_ for _ in os.listdir(path.join(settings.STATIC_DIR, 'js', 'basic', 'modules')) if _.endswith('.js')],
        'chrom': chrom, 'start': start, 'end': end,
        'printer_friendly': friendly,
    }
    return render_to_response('basic/main.html', context, context_instance=RequestContext(request))

# -----------------------------
#  AUTHENTICATION
# -----------------------------

@csrf_protect
@never_cache
def auth_login(request):
    '''Displays the login form and handles the login action.'''
    redirect_to = request.REQUEST.get('next', '')

    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            if not redirect_to or ' ' in redirect_to:
                redirect_to = settings.LOGIN_REDIRECT_URL
            elif '//' in redirect_to and re.match(r'[^\?]*//', redirect_to):
                redirect_to = settings.LOGIN_REDIRECT_URL

            # Okay, security checks complete. Log the user in.
            login(request, form.get_user())
            if request.session.test_cookie_worked():
                request.session.delete_test_cookie()

            return redirect(redirect_to)
    else:
        form = AuthenticationForm(request)

    request.session.set_test_cookie()
    current_site = RequestSite(request)

    return render_to_response('registration/login.html', {
        'settings.APP_URL': settings.APP_URL,                                                                                                    
        'form': form,
        'next': settings.APP_URL + redirect_to,
        'site': current_site,
        'site_name': current_site.name,
    }, context_instance=RequestContext(request))

def auth_logout(request):
    logout(request)
    return redirect(settings.APP_URL + "/")

# -----------------------------
#  SERVICE/SOURCE MANAGERS
# -----------------------------

_whereami = path.normpath(path.dirname(path.abspath(path.realpath(__file__))))
_svc_manager = ModuleManager('browser/services')
_src_manager = ModuleManager('browser/sources')

def basic_service_manager(request, term):
    mod_name, meth_name = term.split('/')[:2]
    return _svc_manager.execute(request, mod_name, meth_name)

def basic_source_manager(request, term):
    mod_name, meth_name = term.split('/')[:2]
    return _src_manager.execute(request, mod_name, meth_name)

# ----------------------------------
#  ANY MANAGER FOR PLUGGABLE MODULE
# ----------------------------------

_any_managers = {}
def basic_any_manager(request, term, dirname):
    mgr = _any_managers.get(dirname)
    if not mgr:
        mgr = ModuleManager(dirname)
    mod_name, meth_name = term.split('/')[:2]
    return mgr.execute(request, mod_name, meth_name)
