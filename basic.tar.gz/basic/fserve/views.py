# Create your views here.
from browser.models import Library
from datetime import datetime, timedelta
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden, HttpResponse, \
  HttpResponseServerError, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from fserve.models import FileGroup, FileLink
from os import path
from util.http import get_params

import gridfs
import glob
import hashlib
import os
import settings
from settings import MONGODBS
from browser.utils import has_perm

def _find_files(dirpath, pattern, recurse=False):
  files = []
  if recurse:
    for d,_,_ in os.walk(dirpath, followlinks=True):
      files += [(path.relpath(d, dirpath), path.basename(f)) 
                for f in glob.glob(path.join(dirpath, d, pattern)) 
                if path.isfile(path.join(dirpath, d, f))]
  else:
    files += [('.', path.basename(f)) 
              for f in glob.glob(path.join(dirpath, pattern)) 
              if path.isfile(path.join(dirpath, f))]
  return files

@login_required
def list_files(request, l):
  context = dict(APP_URL=settings.APP_URL, library=None)
  try:
    lib = Library.objects.get(id=l) # see first whether we're given ID
  except:
    try:
      lib = Library.objects.get(name=l) # then try with name
    except:
      lib = None
  
  if not (lib and has_perm(request, lib)):
    context['library'] = "ACCESS DENIED" if lib else None
    context['noaccess'] = lib 
    context['groups'] = []
    return render_to_response('basic/fserve.html', context, 
                              context_instance=RequestContext(request))

  fgrps = lib.filegroup_set.all()
  groups = []
  for fgrp in fgrps:
    grp = dict(id=fgrp.id, name=fgrp.name)
    incl_files = []
    excl_files = []
    
    for pat in (fgrp.includes or '').split('\n'):
      incl_files += _find_files(fgrp.path, pat, fgrp.recursive)

    for pat in (fgrp.excludes or '').split('\n'):
      excl_files += _find_files(fgrp.path, pat, fgrp.recursive)
  
    grp['files'] = set(incl_files)-set(excl_files)
    groups.append(grp)

  context['library'] = lib.name
  context['groups'] = groups
  return render_to_response('basic/fserve.html', context, 
                            context_instance=RequestContext(request))

_filesys_dict = {}
def get_gridfs(request, file_id):
  module = request.GET.get('module', 'default')
  filesys = _filesys_dict.get(module)
  if not filesys:
      _filesys_dict[module] = filesys = gridfs.GridFS(MONGODBS[module])
      
  f = filesys.get(str(file_id))
  return HttpResponse(f, mimetype=f.content_type)

@login_required
def get_file(request):
  gid, reldir, fname = get_params(request, 'gid', 'reldir', 'fname')
  fgrp = FileGroup.objects.get(id=gid)
  
  # check if this guy actually has access to the library
  if not has_perm(request, fgrp.library):
    return HttpResponseForbidden()
  
  fullpath = path.join(fgrp.path, reldir, fname)
  h = hashlib.sha1(fullpath)
  h.update(str(datetime.now()))

  # housekeep: remove links past 1 day
  try:
    for link in FileLink.objects.filter(accessed_ts__lt=datetime.now() - timedelta(days=1)):
      os.remove(path.join(link.group.path, link.reldir, link.fname))
      os.rmdir(path.join(link.group.path, link.reldir))
      link.delete()
  except:
    print 'Failed to do housekeeping'
  
  try: # see if we still keep the symlink
    link = FileLink.objects.get(fname=fname, reldir=reldir, group=fgrp)
    link.save() # update the access date
    return HttpResponseRedirect(path.join(link.url, fname))
  except:
    print 'No existing symlink. Trying plan B'

  try: # faster method: symlink+redirect
    heck = h.hexdigest()
    os.mkdir(path.join(settings.FSERVE_DIR, heck))
    os.symlink(fullpath, path.join(settings.FSERVE_DIR, heck, fname))
    url = path.join('/static/fserve', heck)
    
    # make entry in database
    link = FileLink(fname=fname, reldir=reldir, group=fgrp, url=url)
    link.save()
    
    return HttpResponseRedirect(path.join(url, fname))
  except:
    print 'Symlink failed. Using plan C'
  
  try:
    f = open(fullpath, 'rb') # automatically closed by Django
    response = HttpResponse(f, mimetype='application/download') # force dialog box to show
    response['Content-Disposition'] = 'attachment; filename=%s'% fname.replace(' ', '_')
    return response
  except:
    return HttpResponseServerError()
