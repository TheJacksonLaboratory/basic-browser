from browser.models import Library
from django.db import models
from os import path

# Create your models here.
class FileGroup(models.Model):
  name = models.CharField(max_length=100)
  path = models.CharField(max_length=500) # absolute path to directory
  recursive = models.BooleanField()
  includes = models.TextField()
  excludes = models.TextField(null=True, blank=True)
  library = models.ForeignKey(Library, null=False) # will inherit permission from this library

  def __unicode__(self):
    return '[%s] %s - %s'% (self.library.name, self.name, self.path)

class FileLink(models.Model):
  '''Keeps track of symbolic links that get created'''
  group = models.ForeignKey(FileGroup)
  reldir = models.CharField(max_length=200, db_index=True)
  fname = models.CharField(max_length=200, db_index=True)
  url = models.CharField(max_length=200)
  accessed_ts = models.DateTimeField(auto_now=True)
  
  def __unicode__(self):
    return '[%s] %s -> %s'% (self.group.name, path.join(self.group.path, self.reldir, self.fname), self.url)
