#!/home/fabianus/BASIC/_python/bin/python
# -------------------------------------------------------------------
#  To be included in all scripts that get called directly from shell
#  It assumes there's a settings.configure() in parent directory
# -------------------------------------------------------------------
from os import path
import sys
_dir = path.join(path.dirname(path.abspath(path.realpath(__file__))), path.pardir)
if _dir not in sys.path: sys.path.append(_dir)
import settings
settings.configure()
# -------------------------------------------------------------------

if __name__ == '__main__':
  import pluginsys
  pluginsys.execute('library')