'''
Created on Feb 17, 2010
Expects stdin like the following:

chr1  /tmp/tmpfile.chr1
chr2  /tmp/tmpfile.chr2
chrX  /tmp/tmpfile.chrX
...

Each temp file should be in the following format:
<chrom>  <position>  <#tags (abs)> <%meth-C (rel)>
chr1   1000   12   44.00  
chr2   2000   6    89.00

@author: mulawadifh
'''

from argparse import ArgumentParser
from fabi.pytools.io import opentemp, cleanup
from fabi.pytools.run import together
from fabi.pytools.shell import Shell, is_sorted, runscript
from gis.basic import countif
from os import path
import os
import shutil
import sys
import tempfile
import yaml

def make_it_so(output, input, size, filterscript):
  _COUNTIF_LIMIT = 32767
  
  root_dir = path.abspath(path.join(path.dirname(path.realpath(__file__)), path.pardir))
  flatstream = path.join(root_dir, "scripts", "awk", "flatstream.awk")
  sh = Shell()
  ratio = 1 # normal ratio
  with opentemp(4, suffix='.cif.tmp') as (tmp1, tmp2, tmp3, tmp4):
    sh("{filterscript} < '{input}' > '{tmp1.name}'".format(**locals()))
    
    # check first if it's already sorted
    sortscript = '' if is_sorted(tmp1.name, '-k 1n,1') else '| sort -k 1n,1'
    
    # NOTE: the awk is meant to get the max value found in tmp2.name,
    # to determine whether we need scaling
    sh("""cat {tmp1.name} {sortscript} 
        | awk -f {flatstream} -v chromsize={size}
        | awk 'BEGIN {{x=0}} {{if ($1>x) x=$1; print;}} END{{print x>"{tmp4.name}"}}'
        > {tmp2.name}""".format(**locals()))

    with open(tmp4.name) as f:
      maxval = int(f.read())
    
    if maxval <= _COUNTIF_LIMIT: 
      inputname = tmp2.name # all clear
    else:
      # uh-oh... time for plan B: scale down the values
      ratio = float(maxval)/_COUNTIF_LIMIT
      sh("awk '{{ print int($1*{_COUNTIF_LIMIT}/{maxval} +0.5) }}' < {tmp2.name} > {tmp3.name}".format(**locals()))
      inputname = tmp3.name

    make = path.join(root_dir, 'console', 'tools', 'make_ds.py')
    runscript(sys.executable, make, 'cif', inputname, output, size)
    
    tmpdir = tempfile.mkdtemp()
    try:
      countif.build(inputname, tmpdir, output, size)
      return ratio
    finally:
      shutil.rmtree(tmpdir)

def main(args):
  # read chromosome sizes
  chrsize = dict()
  with open(args.chromfile) as f:
    for line in f:
      p, q = line.strip().split('\t')
      chrsize[p] = int(q)
  
  if not os.path.exists(args.outdir):
    os.mkdir(args.outdir)

  # read files to process
  tmpfiles = dict()
  for line in sys.stdin:
    line = line.strip()
    if not line: continue
    chrom, tmp = line.split('\t')
    if chrom in chrsize: tmpfiles[chrom] = tmp
  
  # we need three sets of files to display methylation data
  categs = {
    'abs': 'cut -f 2,3',      
    'rel': 'cut -f 2,4',
    
    # absolute criterion is fixed to 'minsup', but we still can adjust the relative criterion
    'mix': r"""awk 'BEGIN{ OFS="\t" }{ if ($3>=%d) print $2,$4 }' """% args.minsup,
  }

  try:
    with together(args.proc) as tog: 
      ciffile = dict() # empty dictionary
      ratios = dict() # empty dictionary
      
      for cat_k, cat_v in categs.iteritems():
        ciffile[cat_k] = dict()
        ratios[cat_k] = dict()
        
        for chrom in chrsize.iterkeys():
          f = "%s.%s.cif.%s"% (args.libname, cat_k, chrom)
          ciffile[cat_k][chrom] = f
          output = os.path.join(args.outdir, f)
          if chrom in tmpfiles: # do not call the method if there's no corresponding file for the given chromosome
            ratios[cat_k][chrom] = tog(make_it_so, output, tmpfiles[chrom], chrsize[chrom], cat_v)
      
    # get the result -- into the same variable
    for cat_k in categs.iterkeys():
      rat = ratios[cat_k]
      for chrom in rat.iterkeys():
        rat[chrom] = rat[chrom].get() # this return the ratio for this chromosome
  
    # create cif file
    for cat_k in categs.iterkeys():
      with open(os.path.join(args.outdir, "%s.%s.cif"% (args.libname, cat_k)), "w") as out:
        ciffile[cat_k]["__lib__"] = args.libname
        ciffile[cat_k]["__ratios__"] = ratios[cat_k]
        out.write(yaml.dump(ciffile[cat_k]))
  finally:
    if not args.no_cleanup:
      cleanup(*tmpfiles.values())

if __name__ == '__main__':
  parser = ArgumentParser()
  parser.add_argument("libname", help="Library name")
  parser.add_argument("chromfile", help="File containing info on chromosome length")
  parser.add_argument("minsup", type=int, help="Minimum number of tags considered significant")
  parser.add_argument("-o", "--outdir", help="Output directory (curdir)", default=".")
  parser.add_argument('-p', '--proc', type=int, help='Number of processors to use (auto)', default=-1)
  parser.add_argument('--no-cleanup', action='store_true', help='Do not delete the list of files passed via stdin')
  args = parser.parse_args()
  sys.exit(main(args))
  