'''
Created on Jun 10, 2011

@author: Fabianus
'''

from argparse import ArgumentParser
from django.contrib.auth.models import User
from os import path
import getpass
import os
import sys
from django.utils.importlib import import_module

def execute(plug_prefix):
  username = getpass.getuser()
  user = User.objects.filter(username=username)

  if not user:
    print >> sys.stderr, "Sorry bro, but your username is not registered in the browser."
    sys.exit(1)

  user = user[0]
  parser = ArgumentParser()
  subpar = parser.add_subparsers()
  
  modules = dict()
  plugdir = path.join(path.normpath(path.dirname(path.abspath(path.realpath(__file__)))), 'plugins', plug_prefix)
  
  for f in os.listdir(plugdir):
    if f.endswith('.py'):
      name = f[:-3]
      mod = import_module('console.plugins.%s.%s' % (plug_prefix, name))
      
      # only add as plugin if it "looks" like a plugin
      if hasattr(mod, 'help') and hasattr(mod, 'config'):
        modules[name] = mod
  
  for modname in sorted(modules.iterkeys()):
    mod = modules[modname]
    
    # check if function permissions() is defined
    perms = mod.permissions() if hasattr(mod, 'permissions') else []
    
    if not user.has_perms(perms):
      # Don't register this module if the user doesn't have the right permission 
      continue
    
    sub = subpar.add_parser(modname, help=mod.help())
    mod.config(sub)

  args = parser.parse_args()
  args.func(args)
