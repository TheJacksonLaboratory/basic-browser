'''
Created on Sep 11, 2011

@author: Fabianus
'''
from browser.models import Library
from django.contrib.auth.models import User, Group
from table.models import Table
  
if __name__ == '__main__':
  # move all owners/groups information from Table to Library
  for lib in Library.objects.all():
    tabs = Table.objects.filter(library=lib)
    owns = list()
    grps = list()
    for t in tabs:
      owns += t.owners.all()
      grps += t.groups.all()
    lib.owners = set(owns)
    lib.groups = set(grps)
    
  # take care of all tables without library
  # create one temporary library for each unique combination of owners+groups
  tabs = Table.objects.filter(library=None)
  ogres = list()
  for t in tabs:
    ogres.append((','.join(_.username for _ in t.owners.all()), 
                  ','.join(_.name for _ in t.groups.all())))
  ogres = sorted(set(ogres))
  
  libcount = 1
  for ogre in ogres:
    owns = User.objects.filter(username__in=ogre[0].split(','))
    grps = Group.objects.filter(name__in=ogre[1].split(','))

    lib = Library(name='_tmp_%03d'% libcount)
    lib.save()
    libcount += 1
    lib.owners = owns
    lib.groups = grps
    
    for t in tabs:
      ogre2 = (','.join(_.username for _ in t.owners.all()), 
               ','.join(_.name for _ in t.groups.all()))
      if ogre == ogre2:
        t.library = lib
        t.save()