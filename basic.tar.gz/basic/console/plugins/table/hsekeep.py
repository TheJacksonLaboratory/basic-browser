'''
Created on Jun 10, 2011

@author: Fabianus
'''
from fabi.pytools.format import intcomma
from util.mongo import BASICollection
from settings import MONGODBS
from table.models import Table
from termcolor import colored
import sys

def help(): 
  return "Deletes orphaned tables (no corresponding Table)"
  
def permissions():
  return ['table.delete_table',]

def config(sub):
  sub.set_defaults(func=hsekeep_tables)

def hsekeep_tables(args):
  recorded_tables = set(str(m.id) for m in Table.objects.all())
 
  # --- MONGODB ---
  
  mongo_tables = set(_[6:] for _ in MONGODBS['default'].collection_names() if _.startswith('table_'))
  orphans = mongo_tables-recorded_tables
  if orphans:
    print
    print colored('\t'.join(('%-21s'% 'Table name', '#Entries')), 'cyan')
    for orp in sorted(orphans):
      tbname = 'table_%s'% orp
      count = BASICollection(orp).count()
      print '\t'.join(('%-21s'% tbname, intcomma(count)))

    print colored('MongoDB collection listed above are orphaned. Delete them all y/[n]? ', 'yellow'),
    if sys.stdin.readline().rstrip().upper() == 'Y':
      for orp in orphans:
        BASICollection(orp).drop()
      msg = '%d collections deleted.'% len(orphans)
    else:
      msg = 'No collections deleted.'
  else:
    msg = 'No orphaned collections'

  print colored(msg, 'white')
