'''
Created on Aug 20, 2011

@author: mulawadifh
'''
from table.models import Table

def get_table_id(table_name_or_id):
  '''ID takes precedence'''
  try:
    by_id = Table.objects.filter(id=table_name_or_id)
    if by_id: return by_id[0].id
  except:
    pass
  
  by_name = Table.objects.filter(name=table_name_or_id)
  l = len(by_name)
  if l==1:
    return by_name[0].id
  elif l==0:
    raise Exception('Table not found.')
  else:
    raise Exception('Multiple entries with the same name found.')
