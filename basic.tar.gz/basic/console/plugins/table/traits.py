'''
Created on Feb 7, 2012

@author: mulawadifh
'''
from table.models import Table
from fabi.pytools.text import parse_range
from util.mongo import BASICollection
from table.traits import predict_traits
from termcolor import colored

def help():
  return "Manage table traits"

def config(sub):
  sub.add_argument('opname', choices=['refresh'], help='Operation')
  sub.add_argument('tables', nargs='?', default=None, help='Table IDs; comma-separated. Omit or specify "all" to list all libraries')
  sub.set_defaults(func=_callback)

def _refresh(table):
  coll = BASICollection(table.id)
  meta = coll.meta()
  if not meta: return
  
  colnames = [_['name'] for _ in meta['columns']]
  traits,_ = predict_traits(colnames)
  oldtraits = meta['traits']
  
  print colored('Table #{0} ({1}):'.format(table.id, table.name), 'yellow')
  print '{0} -> {1}'.format(', '.join(oldtraits), colored(', '.join(traits), 'cyan'))
  
  meta['traits'] = traits
  coll.meta(meta)
  
def _callback(args, **kw): # kw -> criteria passed to filter
  slash = None
  if hasattr(args, 'tables') and args.tables:
    if args.tables == 'all':
      pass # do nothing
    elif ":" in args.tables: # slice notation
      p, q = args.tables.replace("~","-").split(":")
      slash = slice(int(p) if p else None, int(q) if q else None)
    else:
      kw['id__in'] = parse_range(args.tables)
  
  tlist = Table.objects.filter(**kw)
  if slash: tlist = [m for m in Table.objects.filter(**kw)][slash]

  fun = {
    'refresh': _refresh,
  }[args.opname]

  for t in tlist:
    fun(t)