'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.table.list import list_tables
from table.models import Table

import json
import sys
from engine import table_load

def help():
  return "Loads data in tab-separated format into database"
  
def permissions():
  return ['table.add_table',]

def config(parser):
  parser.add_argument('table_id_name', help='Table ID or name in database')
  parser.add_argument('maps', nargs='*', help='Mapping rules in format <column_pos>:<name>[:type][:longname][+]. Plus sign at the end indicates whether the column should be indexed')
  parser.add_argument('-p', '--preset', choices=table_load._PRESETS.keys(), help='Use predefined mappings')
  parser.add_argument('-i', '--input', help='Input file name. If not specified, the script will read from stdin')

  parser.add_argument('-L', '--ljoin', help='Update existing table by intersecting with certain columns (comma-separated names)')

  parser.add_argument('-f', '--force', action='store_true', help='Overwrite existing table (false)')
  parser.add_argument('-s', '--skip-header', type=int, default=-1, help='Number of lines to skip at the beginning (0)')
  parser.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation (false)')
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  table_id = get_table_id(args.table_id_name)
  table_obj = Table.objects.get(id=table_id)
  
  if args.input:
    source = open(args.input) # only present if invoked via function
  else:
    source = sys.stdin
    if source.isatty(): raise Exception('No file specified and no stream from stdin')

  count = table_load.load(source, table_id, args.maps, args.ljoin, args.force, 
                          args.skip_header, preset=args.preset)
  if args.json:
    print json.dumps({ 
      'table-id': table_id,
      'table-name': table_obj.name,  
      'upload-count': count,
    })
  else:
    list_tables(args, id=table_id)
