'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name, aggregate
from console.plugins.track.list import list_tracks
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.io import opentemp
from fabi.pytools.shell import Shell, runscript
from os import path
from util.mongo import BASICollection
from table.models import Table

import json
import settings
import sys
import re

def help():
  return "Generates single/paired tag/cluster track"
  
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("table_id_name", help="Table ID or name")
  parser.add_argument("source", nargs="?", default=None, help="Input source (default=read from database)")
  parser.add_argument('-L', "--tag-length", type=int, help="Tag length", default=0)
  parser.add_argument("-n", "--name", help="Track name")
  parser.add_argument("-d", "--descn", help="Track description (default=None)", default=None)
  parser.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation.')
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  with aggregate(args.source, allow_null=True) as source:
    track = _gen_track_tag(get_table_id(args.table_id_name), args.tag_length, source, args.name, args.descn)
    if args.json:
      print json.dumps({ 'track-id': track.id })
    else:
      list_tracks(args, id=track.id)

def _gen_track_tag(table_id, taglen, source, trk_name, trk_descn):
  mgr = Table.objects.get(id=table_id)
  trk_type = mgr.table_type # happen to have the same name
  
  coll = BASICollection(table_id)
  if coll.has_traits(table_id, 'interval_paired'):
    ds_type = 'paired'
    trait = 'interval_paired'
    trk_type = 'pcls'
  elif coll.has_traits(table_id, 'interval'):
    ds_type = 'paired'
    trait = 'interval'
    trk_type = 'scls'
  elif coll.has_traits(table_id, 'point'):
    ds_type = 'single'
    trait = 'point'
    trk_type = 'scls'
  else:
    raise Exception('Data must have either trait [point], [interval], or [interval_paired]')
  
  trk_name = refine_track_name(trk_name or mgr.name)
  with create_track_tx(mgr, trk_type, trk_name, trk_descn) as track:
    tagname = 'trk_{track.id}'.format(**locals())
    meta_val = path.join(tagname, '%s.%s'% (tagname, ds_type))

    create_metadata(track, source=meta_val)
    chromfile = path.join(settings.GENOME_SIZE_DIR, '%s.txt'% mgr.asm.name)
    gen_xpets(mgr, tagname, chromfile, ds_type, trait, source, taglen)
    return track

def _xform_point(record):
  return '\t'.join(('{_id}', '{chrom}', '{start}', '+')).format(**record)

def _xform_interval(record):
  # WARNING: data structure abuse follows (resulting in the storing of redundant information)
  # for single cluster, we use the "paired" mode to store the anchor's edges 
  return '\t'.join(('{_id}', '{chrom}', '{start}', '{strand}',
                             '{chrom}', '{end}', '{strand}')).format(**record)

def _xform_interval_paired(record):
  # for paired clusters, we represent each cluster with two entries with the same ID
  return '\n'.join(('\t'.join(('{_id}', '{chrom}', '{start}', '{strand}', '{chrom2}', '{start2}', '{strand2}')),
                    '\t'.join(('{_id}', '{chrom}', '{end}', '{strand}', '{chrom2}', '{end2}', '{strand2}')))
                   ).format(**record)

def _strand_masker_single(record): 
  if not 'strand' in record: record['strand'] = '+'

def _strand_masker_paired(record): 
  if not 'strand' in record: record['strand'] = '+'
  if not 'strand2' in record: record['strand2'] = '+'

# also called when generating curve track
def gen_xpets(table, petname, chromfile, ds_type, trait, source=None, taglen=0):
  '''
  source: None (will read from MongoDB) or filename
  ds_type: single/paired
  '''
  outdir = path.join(settings.TRACK_DIR, petname)
  sh = Shell()
  
  try:
    sh("mkdir -p '%s'"% outdir)
  except: pass

  with opentemp() as tmp:
    if not source:
      coll = BASICollection(table.id)
      xformer = globals()['_xform_{0}'.format(trait)]
      masker = globals()['_strand_masker_{0}'.format(ds_type)]
    
      pat = re.compile(r'^chr(?:[MXY]|\d+)$')
      for record in coll.find_all():
        if pat.match(record['chrom']): # ignore random chromosomes
          masker(record)
          tmp.write('%s\n'% xformer(record))
        
      tmp.flush()
      source = tmp.name

    build_xpets = "%s %s"% (sys.executable, path.join(settings.ROOT_DIR, "console", "build_xpets.py"))
    runscript(build_xpets, petname, source, chromfile, ds_type, taglen, outdir=outdir)
