'''
Created on Aug 25, 2011

@author: mulawadifh
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.list import list_tracks
from engine.table_core import create_track_tx
from fabi.pytools.term import stdin_or_editor
from table.models import Table
from table.trackdefs import TRACK_DEFS
import json

def help(): 
  return 'Creates new track'
    
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument('table_id_name', help='Table ID or name')
  parser.add_argument('track_type', help='Track type as defined in table.models.Track', choices=sorted(TRACK_DEFS.iterkeys()))
  parser.add_argument('-n', '--name', help='Track name')
  parser.add_argument('-d', '--descn', action='store_true', help='If specified, will read from stdin/open new editor')
  parser.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation.')
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  table_id = get_table_id(args.table_id_name)
  table = Table.objects.get(id=table_id)
  trk_name = args.name or table.name
  
  trk_descn = None
  if args.descn:
    trk_descn = stdin_or_editor('Please enter description for track [%s]'% args.name)
  
  with create_track_tx(table, args.track_type, trk_name, trk_descn) as track:
    if args.json:
      print json.dumps({ 'track-id': track.id })
    else:
      list_tracks(args, id=track.id)