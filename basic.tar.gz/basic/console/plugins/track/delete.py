'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.track.list import list_tracks
from fabi.pytools.text import parse_range
from table.models import Track, Metadata
from termcolor import colored
import sys

def help():
  return "Deletes a track"
  
def permissions():
  return ['table.delete_track',]

def config(parser):
  parser.add_argument("track_ids", help="Track IDs; comma-separated")
  parser.set_defaults(func=del_tracks)

def del_tracks(args):
  setattr(args, "verbose", False)
  if not list_tracks(args):
    print colored("No tracks found.", "white")
    return
  
  print '\nDelete all these tracks y/[n]? %s '% colored('(THERE IS NO TURNING BACK)', 'red'),
  if sys.stdin.readline().rstrip().upper() != 'Y':
    print colored("Nothing is deleted", "white")
    return
  
  trks = Track.objects.filter(id__in=parse_range(args.track_ids))
  for t in trks:
    for o in Metadata.objects.filter(track=t): o.delete()

  count = len(trks)    
  trks.delete()
  print colored("%d track(s) deleted."% count, "white")
