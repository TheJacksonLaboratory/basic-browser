'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.track.list import list_tracks
from fabi.pytools.text import parse_range
from table.models import Track, Metadata
from termcolor import colored
import sys

def help():
  return "Duplicates a track"
  
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("track_ids", help="Track IDs; comma-separated")
  parser.set_defaults(func=dupe_tracks)

def dupe_tracks(args):
  setattr(args, 'verbose', False)
  if not list_tracks(args):
    print colored("No tracks found.", "white")
    return
  
  print '\nDuplicate the tracks above y/[n]? ',
  if sys.stdin.readline().rstrip().upper() != 'Y':
    print colored("No duplication done.", "white")
    return

  ids = list()  
  trks = Track.objects.filter(id__in=parse_range(args.track_ids))
  for t in trks:
    new_trk = Track(name='%s (copy)'% t.name, descn=t.descn, track_type=t.track_type, table=t.table)
    new_trk.save()
    for o in Metadata.objects.filter(track=t):
      o.id = None
      o.track = new_trk
      o.save()
    ids.append(str(new_trk.id))

  setattr(args, 'verbose', True)
  setattr(args, 'track_ids', ','.join(ids))
  list_tracks(args)