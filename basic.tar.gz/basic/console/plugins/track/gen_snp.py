'''
Created on Nov 24, 2011

@author: mulawadifh
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name
from console.plugins.track.gen_xpets import gen_xpets
from console.plugins.track.list import list_tracks
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.io import opentemp
from fabi.pytools.shell import Shell, ShellChain, split_by_col
from os import path
from util.mongo import BASICollection
from table.models import Table
import json
import settings
import sys

def help():
  return "Generates SNP track from table"
  
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("table_id_name", help="Table ID or name")
  parser.add_argument("-n", "--name", help="Track name")
  parser.add_argument("-d", "--descn", help="Track description (default=None)", default=None)
  parser.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation.')
  parser.set_defaults(func=_callback)

def _callback(args):
  track = _make_track(get_table_id(args.table_id_name), args.name, args.descn)
  if args.json:
    print json.dumps({ 'track-id': track.id })
  else:
    list_tracks(args, id=track.id)

def _make_snp_ds(tagname, coll, chromfile, outdir):
  py = sys.executable
  splitter = path.join(settings.PYSCRIPT_DIR, 'splitbycol.py')
  builder = path.join(settings.ROOT_DIR, 'console', 'build_gaprs.py')
  snpnames = dict()
  
  # we do it per chromosome
  # ideally, it should be per group, but the organization of the data doesn't allow that
  sh = Shell()
  with opentemp() as tmpfile:
    for row in coll.find_all():
      chrom, start = row['chrom'], row['start']
      for grp in (_['name'] for _ in row['groups']):
        tmpfile.write('{grp}\t{chrom}\t{start}\n'.format(**locals()))
    
    tmpfile.flush()
    with split_by_col(tmpfile.name, 1) as first_splits:
      for grp, file1 in first_splits.iteritems():
        snpname = '{tagname}_grp{grp}'.format(**locals())
        ch = (ShellChain().context(locals())
                          .chain('cut -f2- < {file1}')
                          .chain('{py} {splitter} 1')
                          .chain('{py} {builder} {snpname} {chromfile} -o {outdir}'))
        snpnames[grp] = path.join(tagname, path.basename(ch.execute())).strip() # relative path
  return snpnames

def _make_track(table_id, trk_name, trk_descn):
  table = Table.objects.get(id=table_id)

  trk_name = refine_track_name(trk_name or table.name)
  trk_type = 'snp'
  ds_type = 'single'
  trait = 'point'
  
  with create_track_tx(table, trk_type, trk_name, trk_descn) as track:
    tagname = 'trk_{track.id}'.format(**locals())
    xpet_val = path.join(tagname, '{tagname}.{ds_type}'.format(**locals()))

    asm = table.asm.name
    chromfile = path.join(settings.GENOME_SIZE_DIR, '%s.txt'% asm) 
    gen_xpets(table, tagname, chromfile, ds_type, trait) # source=None --> get from MongoDB

    outdir = path.join(settings.TRACK_DIR, tagname)
    coll = BASICollection(table_id)
    gaprs_val = _make_snp_ds(tagname, coll, chromfile, outdir)
    
    create_metadata(track, **{'source.xpet': xpet_val,
                              'source.gaprs': gaprs_val})
    return track
