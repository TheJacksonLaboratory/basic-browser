'''
Created on Sep 11, 2011

@author: Fabianus
'''
from browser.models import TargetFactor, CellLine, Technology, Library, Project
from console.plugins.library.list import list_libraries
from fabi.pytools.term import stdin_or_editor
from fabi.pytools.text import parse_range

def help():
  return "Edit libraries"

def permissions():
  return ['browser.change_library',]

def config(sub):
  sub.add_argument("libs", help="Library IDs; comma-separated")
  sub.add_argument("assgs", nargs='?', default=[], help="Assignments (target/cell/tech=?); leave empty to edit library description")
  sub.set_defaults(func=_edit)

def _edit(args, **kw):
  if hasattr(args, 'libs') and args.libs:
    try:
      kw['id__in'] = parse_range(args.libs)
    except:
      kw['id__in'] = [Library.objects.get(name=_).id for _ in args.libs.split(',')]
  
  maps = dict(
    target = (TargetFactor, 'code'),
    cell   = (CellLine, 'name'),
    tech   = (Technology, 'name'),          
    proj   = (Project, 'name'),
  )
  
  libs = list(Library.objects.filter(**kw))
  if len(libs) == 1 and not args.assgs:
    # one library + no assignment = edit description
    l = libs[0]
    descn = stdin_or_editor('Please enter description for library [%s]'% l.name, preloaded=l.descn)
    if descn is not None:
      l.descn = descn
      l.save()
    list_libraries(args)
    return
  
  # else, edit assignments
  if type(args.assgs) == str:
    args.assgs = [args.assgs]
  for l in libs:
    for asg in args.assgs:
      k, v = asg.split('=')
      m, n = maps[k]
      setattr(l, k, m.objects.get(**{ n: v }) if v else None)
    l.save()
  list_libraries(args)
