'''
Created on Sep 14, 2011

@author: mulawadifh
'''
from browser.models import Library
from fabi.pytools.term import stdin_or_editor
from fserve.models import FileGroup
from os import path
from termcolor import colored
import sys
import yaml

def help():
  return 'Manage file sharing'

def config(parser):
  subpar = parser.add_subparsers()
  sub = subpar.add_parser('new', help='Create new sharing group')
  
  sub.add_argument('libname', help='Library name')
  sub.add_argument('share_name', help='Share name')
  sub.add_argument('--path', required=True, help='Absolute path to the directory containing files to be shared')
  sub.add_argument('-r', '--recursive', action='store_true', help='Whether to look for files recursively')
  sub.add_argument('--includes', default='', help='Comma-separated inclusive pattern, e.g. *.xls,*.txt')
  sub.add_argument('--excludes', default='', help='Comma-separated exclusive pattern, e.g. *.log')
  sub.set_defaults(func=_new)

#class FileGroup(models.Model):
#  name = models.CharField(max_length=100)
#  path = models.CharField(max_length=500) # absolute path to directory
#  recursive = models.BooleanField()
#  includes = models.TextField()
#  excludes = models.TextField(null=True, blank=True)
#  library = models.ForeignKey(Library, null=False) # will inherit permission from this library

def _new(args):
  lib = Library.objects.get(name__iexact=args.libname)
  if FileGroup.objects.filter(library=lib, name__iexact=args.share_name):
    print colored('ERROR: Share with that name already defined for library %s'% lib.name, 'red')
    sys.exit(1)
  
  data = dict(name=args.share_name, path=path.abspath(path.normpath(args.path)), recursive=args.recursive,
              includes=args.includes.split(','), 
              excludes=args.excludes.split(','))
  
  msgs = ['Please set the include/exclude filters for path [%s]'% args.path]
  newdata = yaml.dump(data)

  while True:
    if not args.includes:
      # if include pattern is not specified, open editor
      newdata = stdin_or_editor(message=msgs, preloaded=yaml.dump(data, default_flow_style=False))
      
    if newdata: 
      try:
        obj = yaml.load(newdata)
        obj['includes'] = '\n'.join(obj['includes'] or [])
        obj['excludes'] = '\n'.join(obj['excludes'] or [])
        fgroup = FileGroup(library=lib, **obj)
        fgroup.save()
        print colored('New share created: %s'% fgroup, 'white')
        break
      except Exception as e:
        msgs.insert(0, 'ERROR: %s'% e)
        continue # if user saved, but not parsable, reopen the editor
    else:
      print colored('No share created', 'white')
      break