'''
Created on Dec 12, 2011

@author: mulawadifh
'''
from contextlib import contextmanager
from fabi.pytools.format import humantime
from fabi.pytools.shell import Shell, runscript as _run_it
from os import path

import logging
import settings
import sys
import time

_SCRIPT_DIR = path.join(settings.ROOT_DIR, 'console')

_PY = sys.executable
LIB = '%s "%s"'% (_PY, path.join(_SCRIPT_DIR, 'library_util.py'))
TAB = '%s "%s"'% (_PY, path.join(_SCRIPT_DIR, 'table_util.py'))
TRK = '%s "%s"'% (_PY, path.join(_SCRIPT_DIR, 'track_util.py'))
CHROMIFY = '%s "%s"'% (_PY, path.join(_SCRIPT_DIR, 'tools', 'chromify.py'))

def _get_logger():
  #create logger
  log = logging.getLogger('BASIC Batch Script')
  log.setLevel(logging.DEBUG)
  
  #console handler
  shand = logging.StreamHandler()
  shand.setLevel(logging.DEBUG)
  
  #create formatter
  formatter = logging.Formatter('%(asctime)s %(levelname)5s [%(name)s] %(message)s')
  shand.setFormatter(formatter)
  
  #add handler to logger
  log.addHandler(shand)
  return log

class _TimerShell(Shell):
  @contextmanager
  def _wrap(self, cmd):
    if self._logger: self._logger.debug('START [%s]'% cmd)
    start_time = time.time()
    yield
    elapsed = humantime(time.time()-start_time)
    if self._logger: self._logger.debug('END [%s]. Time _elapsed: %s\n'% (cmd[:30] if len(cmd)<30 else cmd[:27]+'...', elapsed))
  
  def __init__(self, logger):
    super(Shell, self).__init__()
    self._logger = logger
  
  def __call__(self, cmd, *args, **kwargs):
    with self._wrap(cmd):
      return super(_TimerShell, self).__call__(cmd, *args, **kwargs)

_sh = _TimerShell(logger=_get_logger())
def runscript(*args, **kwargs):
  out, _ = _run_it(_shell=_sh, *args, **kwargs)
  return out
