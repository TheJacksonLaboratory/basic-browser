'''
Provides two main methods:
  - To create new table entry in browser's database.
  - To load data from stdin/file into the newly created table.
'''

from table.traits import predict_traits
from util.mongo import BASICollection
from os import path

import string
import random
import sys
import yaml
import settings

# --- Read pre-defined file formats

_formatfile = path.join(settings.ROOT_DIR, 'engine', 'fileformat_defs.yaml')
_PRESETS = dict()

with open(_formatfile) as f:
  raw_presets = yaml.load(f)
  for presetname, preset in raw_presets.iteritems():
    mapping = list()
    for i,m in preset['mapping'].iteritems():
      if type(m) is str:
        mapping.append('{0}:{1}'.format(i,m))
      elif type(m) is dict:
        name = m['name']
        mapstr = ':'.join((name, m.get('type', 'str'), m.get('long_name', name)))
        if m.get('indexed'): mapstr += '+'
        mapping.append('{0}:{1}'.format(i,mapstr))
      else:
        raise ValueError('Unexpected type: {0} ({1})'.format(m, type(m)))
      
    _PRESETS[presetname] = {
      'comment_marker': preset.get('comment_marker', ''),
      'skip_header': preset.get('skip_header', 0), # this is where the real default value for [skip_header] is defined                      
      'mapping': mapping,                   
    }

# ---

class AbstractUploader(object):
  def __init__(self, table_id, srcfile, nlines=1, drop=False):
    self.srcfile = srcfile
    self.nlines = nlines # number of lines that makes up one MongoDB document
    
    self.coll = BASICollection(table_id)
    if drop: self.coll.drop()
  
  def preprocess(self, coll, srcfile): pass
  
  def postprocess(self, coll, srcfile): pass
  
  def convert(self, lines):
    '''Converts one or more lines from source file into one document'''
    raise NotImplementedError()

  def _save_doc(self, doc):
    self.coll.save(doc)

  def _process_fast(self): 
    # for common case where nlines=1
    for line in self.srcfile:
      doc = self.convert(line)
      if doc: self._save_doc(doc)

  def _process(self):
    line_count = 0
    line_buffer = list()
    for line in self.srcfile:
      line_buffer.append(line)
      line_count += 1
      if line_count == self.nlines:
        doc = self.convert(line_buffer)
        if doc: self._save_doc(doc)
        del line_buffer[:]
        line_count = 0

  def run(self):
    self.preprocess(self.coll, self.srcfile)
    if self.nlines == 1:
      self._process_fast()
    else:
      self._process()
    self.postprocess(self.coll, self.srcfile)
    
class IndexBasedUploader(AbstractUploader):
  def __init__(self, table_id, srcfile, mapping, types=None, sep='\t', drop=False):
    super(IndexBasedUploader, self).__init__(table_id, srcfile, drop=drop)
    self.mapping = mapping # e.g. { 0: 'chrom', 1: 'start', 2: 'end' }
    self.maplen = len(mapping)
    self.item_id = 0
    self.sep = sep
    self.types = types or {}
  
  def convert(self, line):
    arr = line.strip().split(self.sep)
    try:
      l = len(arr)
      doc = dict((v, self.types.get(v, str)(arr[k]) if k<l and arr[k] else None) for k,v in self.mapping.iteritems())
    except:
      return None
    self.item_id += 1
    if not '_id' in doc: doc['_id'] = self.item_id # if not specified in the mapping, use our own running ID
    return doc

  def upload_count(self):
    return self.item_id

# --- HIGHER-LEVEL FUNCTION

def _parse_mapstring(mapstrlist, predictions):
  result = dict()
  for mapstr in mapstrlist:
    if mapstr[-1] == '+': # plus sign indicates that the column must be indexed 
      idx = True
      mapstr = mapstr[:-1]
    else:
      idx = False
      
    arr = mapstr.split(':')
    l = len(arr)
    
    if arr[1] in predictions:
      # if there is definition because of matching names with traits, use it
      d = predictions[arr[1]]
    else:
      d = dict(name=arr[1], long_name=arr[1], type='str', indexed=idx)

    # user-specified values take priorities, however    
    if l>2 and arr[2]: d['type'] = arr[2]
    if l>3 and arr[3]: d['long_name'] = arr[3]
    if idx: d['indexed'] = True
    result[int(arr[0])] = d
  return result

def _bool_convert(b):
  t = type(b)
  if t == int:
    return bool(b)
  elif t == str:
    b = b.strip().upper()
    if len(b) == 1:
      if b in 'TY1':
        return True
      elif b in 'FN0':
        return False
    else:
      if b in ('TRUE', 'YES'):
        return True
      elif b in ('FALSE', 'NO'):
        return False
  return None

def _float_convert(f):
  try:
    return float(f)
  except:
    return None

def _int_convert(i):
  try:
    return int(i)
  except:
    return None

_TYPE_MAP = {
  'int': _int_convert,
  'float': _float_convert,
  'bool': _bool_convert,
}

def load(source, table_id, maps=None, ljoin=None, forceful=False, skiplines=0, 
         preset=None, uploader_cls=IndexBasedUploader):
  
  if not maps:
    if preset:
      p = _PRESETS[preset]
      maps = p['mapping']
      if skiplines < 0:
        skiplines = p['skip_header']
    else:
      raise Exception('No mapping or preset specified')
  
  coll = BASICollection(table_id)
  if coll.count() > 0 and not (forceful or ljoin):
    raise Exception('There is existing data. Use --force to overwrite them')

  if forceful: coll.drop()
  if type(source) is str:
    inputsource = open(source)
  else: # assume it's file object
    inputsource = source

  colnames = [_.split(':')[1] for _ in maps]
  traits, preds = predict_traits(colnames)
  
  parsed = _parse_mapstring(maps, preds)
  types = dict((_['name'], _TYPE_MAP.get(_['type'], str)) for _ in parsed.itervalues())
  mappings = dict((p-1, q['name']) for p,q in parsed.iteritems())

  meta = dict(
    version=1.0,
    columns=parsed.values(),
    traits=traits,
  )

  upload_id = table_id
  try:
    # skip N number of lines
    for _ in xrange(skiplines):
      inputsource.next()
    
    if ljoin:
      # temp table ID
      choices = string.ascii_letters + string.digits
      upload_id = ''.join(random.choice(choices) for _ in xrange(20))
    
    coll = BASICollection(upload_id)
    coll.meta(meta) # metadata
    
    upload = uploader_cls(upload_id, inputsource, mappings, types)
    upload.run()
    
    if ljoin:
      # do left join with the temp table, then delete the temp
      xsect = [_ for _ in ljoin.split(',') if _[0] != '-']
      exclu = [_[1:] for _ in ljoin.split(',') if _[0] == '-']
      left_join(BASICollection(table_id), coll, xsect, exclu)
    else:
      # create indexes
      for col in meta['columns']:
        if col['name'] == 'id': continue
        if col['indexed']: coll.create_index(col['name'])
    
    return coll.count()-1 # minus metadata
  finally:
    if inputsource != sys.stdin:
      inputsource.close()
    if ljoin:
      BASICollection(upload_id).drop() # drop temp table

def left_join(ltable, rtable, join_cols, exclude_cols=None):
  '''
  ltable and rtable must be of type BASICollection
  
  STEPS
    1. join columns must be indexed in ltable 
    2. join columns must present in ltable and rtable metadata
    3. no shared column names between ltable and rtable, besides join cols and excluded cols
  '''
  
  # STEP 1 - join columns must be indexed in ltable
  lindexes = set(','.join(x[0] for x in _['key']) for _ in ltable.index_information().itervalues())
  for c in join_cols:
    if c not in lindexes: 
      raise Exception('Column {0} in ref table is not indexed'.format(c))
  
  lmeta = ltable.meta()
  rmeta = rtable.meta()
  
  lcols = lmeta['columns']
  rcols = rmeta['columns']
  
  # STEP 2 - join columns must present in ltable and rtable metadata
  joinset = set(join_cols)
  lcolset = set(_['name'] for _ in lcols)
  rcolset = set(_['name'] for _ in rcols)
  if not (lcolset >= joinset <= rcolset):
    raise Exception('Join columns must be present in both left and right tables')
  
  # STEP 3 - no shared column names between ltable and rtable, besides join cols and excluded cols
  xcolset = set(exclude_cols or [])
  overlaps = ((lcolset & rcolset) - joinset - xcolset)
  if overlaps:
    raise Exception('There are overlap(s) in table columns: {0}'.format(list(overlaps)))
  
  # LET'S RUMBLE!
  
  # --- update meta
  m = ltable.meta()
  traits,_ = predict_traits(lcolset | rcolset)
  addset = rcolset - joinset - xcolset
  m['columns'] += [_ for _ in rcols if _['name'] in addset]
  m['traits'] = traits
  ltable.meta(m)
  
  # --- update data
  for rrow in rtable.find_all():
    q = dict((_,rrow[_]) for _ in join_cols)
    del rrow['_id']
    for c in xcolset: del rrow[c] # excluded columns
    for lrow in ltable.find(q):
      lrow.update(rrow)
      ltable.save(lrow)
      
  # --- indexes please
  for col in (set(_['name'] for _ in rcols if _['indexed']) - joinset - xcolset):
    ltable.create_index(col)
