'''
Contains (transactional) functions to create:
- table Table
- Track
- Metadata
'''

from browser.models import Assembly, Library
from contextlib import contextmanager
from table.models import Table, Track, Metadata, MetaTable
from table.trackdefs import TRACK_DEFS
import json

@contextmanager
def create_table_tx(name, asm, descn, lib=None):
  '''Creates a new entry in table.Table'''
  table = None
  try:
    asm = Assembly.objects.get(name=asm)
    table = Table(name=name, asm=asm, descn=descn)
    table.save()
    
    if lib:
      table.library = Library.objects.get(name=lib)
    
    table.save()
    yield table
    table.save()
  except:
    if table and table.id: table.delete() # delete the previously created Table on error
    raise

@contextmanager
def create_track_tx(mgr, track_type, trk_name, descn=None): # mgr can be Djangobject or ID
  trk = None
  if track_type not in TRACK_DEFS:
    raise Exception("Unsupported track type: [%s]. Choices: [%s]"% (track_type, ', '.join(TRACK_DEFS.iterkeys())))
  
  try:
    if type(mgr) is int:
      mgr = Table.objects.get(id=mgr)
    # create new track
    trk = Track(track_type=track_type, name=trk_name, descn=descn, table=mgr)
    trk.save()
    yield trk
  except:
    if trk and trk.id: trk.delete()
    raise

# we don't need a 'tx' version, as metadatas are usually created together with within
# 'create_track_tx' block, and gets deleted together with the Track if there's an exception
def create_metadata(track, **kwargs):
  if type(track) == int:
    track = Track.objects.get(id=track)
  for k,v in kwargs.iteritems():
    m = Metadata(track=track, key=k, value=json.dumps(v))
    m.save()

def create_metatable(table=None, **kwargs):
  # NOTE: this function will overwrite existing entry with the same 'key'
  for k,v in kwargs.iteritems():
    if table and not type(table) is Table:
      table = Table.objects.get(id=table)
    try:
      meta = MetaTable.objects.get(key=k)
      meta.value = json.dumps(v)
    except:
      meta = MetaTable(key=k, value=json.dumps(v))
    finally:
      meta.table = table
      meta.save()

def iter_mcoll(coll, limit=None): # coll is MongoDB collection
  for i,item in enumerate(coll.find_all()):
    if limit and i >= limit: break
    yield item
