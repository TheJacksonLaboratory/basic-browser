from django.contrib import admin
from table.models import *

class _TrackInline(admin.TabularInline):
  model = Track
class _MetadataInline(admin.TabularInline):
  model = Metadata
class _MetableInline(admin.TabularInline):
  model = MetaTable

class TableAdmin(admin.ModelAdmin):
  ordering = ('-id',)
  inlines = [ _TrackInline ]

  def _asm_name(t): return t.asm.name
  _asm_name.short_description = "Assembly"
  list_display = ('id', 'name', 'library', 'descn', _asm_name)
  list_filter = ('asm', 'library',)
  inlines = [ _MetableInline, _TrackInline ]

class MetaTableAdmin(admin.ModelAdmin):
  list_display = ('id', 'key', 'value',)

class MetadataAdmin(admin.ModelAdmin):
  ordering = ('-id',)
  list_display = ('id', 'track', 'key', 'value', 'owner',)

class TrackAdmin(admin.ModelAdmin):
  ordering = ('-id',)
  list_display = ('id', 'name', 'descn', 'track_type', 'table')
  list_filter = ('track_type', 'table',)
  inlines = [ _MetadataInline ]

admin.site.register(MetaTable, MetaTableAdmin)
admin.site.register(Table, TableAdmin)
admin.site.register(Track, TrackAdmin)
admin.site.register(Metadata, MetadataAdmin)
