'''
Sets up BASIC Browser.
This script performs the following:
- creates directories './bin' and './log'
- calls 'make' in directory './src'
- calls 'setup.py build' and 'sudo setup.py build' in directory './ds'  
- generates 'django.wsgi'
- generates 'basic.vhost', to be included in Apache HTTP config file

Created on Jun 10, 2011

@author: mulawadifh
'''

from argparse import ArgumentParser
from os import path
import os
import re
import stat
import subprocess as sp
import sys

# --------------------------------------------------------------------------------

def which(file_):
    """Finds executable file in the PATH"""
    for path in os.environ.get("PATH", []).split(os.pathsep):
        if os.access(os.path.join(path, file_), os.X_OK):
            return os.path.join(path, file_)
    return None


class Shell(object):
    class ShellException(Exception):
        def __init__(self, xyz, stdout, stderr):
            super(Shell.ShellException, self).__init__(xyz)
            self.stdout = stdout
            self.stderr = stderr

    def __init__(self, cmd=None, input_=None, output=sp.PIPE, error=sp.PIPE):
        if cmd: self.__call__(cmd, input_, output, error) # allowing shortcut like: Shell('ls') instead of Shell()('ls')

    def __call__(self, cmd, input_=None, output=sp.PIPE, error=sp.PIPE):
        '''
        input_ = either string, stream, or nothing
        '''
        cmd = re.sub('\s{2,}', ' ', cmd)

        if type(input_) == str:
            stdin = sp.PIPE
        elif type(input_) == file:
            stdin = input_
            input_ = None
        else:
            stdin = None

        proc = sp.Popen(cmd, shell=True, stdin=stdin, stdout=output, stderr=error)
        out, err = proc.communicate(input_)

        if proc.returncode != 0:
            raise Shell.ShellException(
                "Execution failed: '%s'. Input: '%s'; Output: '%s'; Error: '%s'" % (cmd, input_, out, err), out, err)

        return out, err # only returned on success

# --------------------------------------------------------------------------------

def get_progs():
    '''Checks if all necessary tools are available'''
    REQ_PROGS = ('virtualenv', 'swig',)
    progs = dict()
    for p in REQ_PROGS:
        w = which(p)
        if not w: raise Exception(
            "Cannot find '{p}'. Please make sure it is installed and its location is specified in PATH".format(
                **locals()))
        progs[p] = w
    return progs


def error(msg):
    print >> sys.stderr, '[ERROR] %s' % msg


def warn(msg):
    print >> sys.stderr, '[WARN] %s' % msg


def info(msg):
    print '[INFO] %s' % msg


def run_pysetup(mod_dir, python):
    bak_dir = path.abspath(os.curdir) # store current directory
    os.chdir(mod_dir)
    Shell('''{python} setup.py build install'''.format(**locals()), output=sys.stdout)
    os.chdir(bak_dir) # restore directory


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('extsds_dir', help='Directory containing extsds binary files')
    parser.add_argument('pytools_dir', help='Directory containing pytools files')

    parser.add_argument('--python', help='Directory for python virtual environment')
    parser.add_argument('--port', type=int, help='Port number to be used in Apache config (8001)', default=8001)
    parser.add_argument('--server-name', help='Server name to be used in Apache config (example.com)',
                        default='example.com')
    parser.add_argument('--admin-email', help='Email address to be used in Apache config (you@example.com)',
                        default='you@example.com')
    parser.add_argument('-F', '--force', action='store_true', help='Overwrite any existing directory/file')
    args = parser.parse_args()

    # check first whether we're at the right place
    if path.abspath(path.dirname(path.realpath(__file__))) != path.abspath(path.curdir):
        error("Dude, you should run me from the directory where I'm located.")
        sys.exit(1)

    # get the path to required programs
    progs = get_progs()
    sh = Shell()

    DIRS = ('log', '.python-eggs') # these two directories must be writable by Apache
    for d in DIRS:
        if not path.exists(d):
            os.mkdir(d)
            info('Created directory {dir}'.format(dir=path.abspath(path.join(path.curdir, d))))
        else:
            warn('Directory {dir} already exists'.format(dir=path.abspath(path.join(path.curdir, d))))
        os.chmod(d, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)
    info('DONE')

    basic_dir = path.abspath(os.curdir)

    # if --python is specified, create a virtual environment
    if args.python:
        info('Creating python virtual env')
        sh('virtualenv -p {p} --no-site-packages {vdir}'.format(p=sys.executable, vdir=path.abspath(args.python)),
           output=sys.stdout)
        python = path.join(path.abspath(args.python), 'bin', 'python')
    else:
        info('Using current python')
        python = sys.executable

    # install utility module (fabi-pytools)
    info('Installing utility module (fabi-pytools)...')
    run_pysetup(path.abspath(args.pytools_dir), python)

    # install required python modules from cheese shop
    info('Installing required python modules from PyPI, and also secretDS...')
    run_pysetup(path.join(basic_dir, 'ds'), python)

    force_flag = '--force' if args.force else ''
    info('Calling setup.py using python from virtualenv to generate WSGI file')
    sh('{python} setup_helper.py {force_flag} wsgi'.format(**locals()),
       output=sys.stdout, error=sys.stderr)

    # generate basic.conf for apache
    info('Calling setup.py using python from virtualenv to generate Apache config file')
    sh('''{python} setup_helper.py {force_flag} vhost
        --port={port} --server-name={server_name} --admin-email={admin_email}'''
       .format(port=args.port, server_name=args.server_name, admin_email=args.admin_email, **locals()),
       output=sys.stdout, error=sys.stderr)

    # build and install C++ modules
    info('Copying extsds files to python module directory')
    sh('{python} setup_helper.py {force_flag} extsds {extsds_dir}'
       .format(extsds_dir=path.abspath(args.extsds_dir), **locals()), output=sys.stdout, error=sys.stderr)
  